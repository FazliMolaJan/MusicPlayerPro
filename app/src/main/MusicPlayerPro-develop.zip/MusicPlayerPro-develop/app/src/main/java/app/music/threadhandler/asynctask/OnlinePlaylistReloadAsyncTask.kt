package app.music.threadhandler.asynctask

import android.content.Context
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import app.music.adapter.OnlinePlaylistAdapter
import app.music.base.BaseReloadListAsyncTask
import app.music.model.OnlinePlaylist
import app.music.utils.musicloading.LoadMusicUtil
import java.lang.ref.WeakReference
import java.util.*

class OnlinePlaylistReloadAsyncTask<C : Comparator<in OnlinePlaylist>>(
        fragmentReference: WeakReference<Fragment>, recyclerAdapter: OnlinePlaylistAdapter,
        refreshLayoutReference: WeakReference<SwipeRefreshLayout>, comparator: C)
    : BaseReloadListAsyncTask<OnlinePlaylist, C, OnlinePlaylistAdapter>(
        fragmentReference, recyclerAdapter, refreshLayoutReference, comparator) {

    override fun reloadTypeList() {
        LoadMusicUtil.getOnlinePlaylist(WeakReference<Context>(mFragmentReference.get()?.context))
    }

    override fun getTypeList(): List<OnlinePlaylist> = LoadMusicUtil.sOnlinePlaylistList
}
