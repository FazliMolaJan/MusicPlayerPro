package app.music.utils.progresscanceling

import android.os.AsyncTask

object ProgressCancelingUtils {

    fun cancelAsyncTask(asyncTask: AsyncTask<*, *, *>?) {
        asyncTask?.cancel(true)
    }
}
