package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import android.support.v7.widget.RecyclerView
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemHomeFifthFragmentBinding
import app.music.diffcallback.PlaylistDiffCallBack
import app.music.listener.PlaylistFragmentItemClickListener
import app.music.model.Playlist
import app.music.utils.recyclerview.RecyclerViewUtils
import app.music.viewholder.PlaylistViewHolder
import java.lang.ref.WeakReference

class PlaylistAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<Playlist, PlaylistViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): PlaylistViewHolder {
        return PlaylistViewHolder(mActivityReference, binding as ItemHomeFifthFragmentBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
        return object : PlaylistFragmentItemClickListener {
            override fun onPlaylistClick(playlist: Playlist, isLongClick: Boolean) {
                (activity as PlaylistFragmentItemClickListener).onPlaylistClick(playlist, isLongClick)
            }
        }
    }

    override fun getDiffResult(isFilter: Boolean, dataList: List<Playlist>, newItems: List<Playlist>)
            : DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(PlaylistDiffCallBack(dataList, newItems), false)
    }

    override fun getLayoutId(): Int = R.layout.item_home_fifth_fragment

    override fun isContainingFilterPatternItem(item: Playlist, filterPattern: String): Boolean {
        return item.playlistName.toLowerCase().contains(filterPattern)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        RecyclerViewUtils.setToolbarScrollFlag(recyclerView, mActivityReference)
    }
}
