package app.music.viewholder

import android.app.Activity
import android.content.Context
import android.databinding.ObservableField
import android.support.v7.widget.RecyclerView
import android.view.View
import app.music.R
import app.music.base.BaseViewHolder
import app.music.databinding.ItemHomeSecondFragmentBinding
import app.music.listener.SongItemClickListener
import app.music.listener.dialoglistener.DialogSongOptionListener
import app.music.model.BaseMusik
import app.music.utils.dialog.songoption.DialogSongOptionMethodUtils
import app.music.utils.imageloading.ImageLoadingUtils
import com.bumptech.glide.request.RequestOptions
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat

class MusicViewHolder
(weakReference: WeakReference<Activity>, itemView: ItemHomeSecondFragmentBinding)
    : BaseViewHolder<BaseMusik, ItemHomeSecondFragmentBinding, SongItemClickListener>
(weakReference, itemView),
        View.OnClickListener,
        View.OnLongClickListener {

    var song = ObservableField<String>()
    var artist = ObservableField<String>()
    var duration = ObservableField<String>()
    private val mSimpleDateFormat = SimpleDateFormat("mm:ss")
    private val mRequestOptions = RequestOptions()
            .error(R.drawable.ic_disc_56dp)
            .override(100, 100)
            .centerCrop()

    init {
        itemView.btnOption.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        val position by lazy { adapterPosition }
        if (mItemClickListener == null || position == RecyclerView.NO_POSITION) return
        when (v.id) {
            R.id.btn_option -> {
                DialogSongOptionMethodUtils.showSongOption(
                        mViewHolderWeakReference.get() as DialogSongOptionListener, mDataList[position])
            }
            else -> {
                mItemClickListener?.onSongClick(position, mDataList, false)
            }
        }
    }

    override fun onLongClick(v: View): Boolean {
        val position by lazy { adapterPosition }
        if (mItemClickListener == null || position == RecyclerView.NO_POSITION) return true
        DialogSongOptionMethodUtils.showSongOption(
                mViewHolderWeakReference.get() as DialogSongOptionListener, mDataList[position])
        return true
    }

    override fun bindData(dataObject: BaseMusik) {
        if (mBinding.itemview == null) {
            mBinding.itemview = this
        }
        dataObject.let {
            val context by lazy { mViewHolderWeakReference.get() as Context }
            val defaultValue by lazy { context.getString(R.string.empty_string) }
            setStringObservableFieldValue(context, song, it.title, defaultValue)
            setStringObservableFieldValue(context, artist, it.artist, defaultValue)
            setStringObservableFieldValue(context, duration, mSimpleDateFormat.format(it.duration), defaultValue)
            ImageLoadingUtils.loadMusicImage(it, mMetadataRetriever, mRequestOptions, mBinding.coverArt)
        }
    }
}
