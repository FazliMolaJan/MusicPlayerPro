package app.music.threadhandler.asynctask

import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import app.music.adapter.ArtistAdapter
import app.music.base.BaseReloadListAsyncTask
import app.music.model.Artist
import app.music.utils.musicloading.LoadMusicUtil
import java.lang.ref.WeakReference
import java.util.*

class OnlineArtistReloadAsyncTask<C : Comparator<in Artist>>(
        fragmentReference: WeakReference<Fragment>, recyclerAdapter: ArtistAdapter,
        refreshLayoutReference: WeakReference<SwipeRefreshLayout>, comparator: C)
    : BaseReloadListAsyncTask<Artist, C, ArtistAdapter>(
        fragmentReference, recyclerAdapter, refreshLayoutReference, comparator) {

    override fun reloadTypeList() = LoadMusicUtil.getOnlineArtist()

    override fun getTypeList(): List<Artist> = LoadMusicUtil.sOnlineArtistList
}
