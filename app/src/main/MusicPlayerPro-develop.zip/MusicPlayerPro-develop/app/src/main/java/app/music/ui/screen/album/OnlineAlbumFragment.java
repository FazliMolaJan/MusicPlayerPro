package app.music.ui.screen.album;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;

import java.lang.ref.WeakReference;
import java.util.Comparator;

import app.music.R;
import app.music.adapter.AlbumAdapter;
import app.music.base.BaseFragment;
import app.music.comparator.comparatorascending.album.AlbumComparatorByAlphabetAscending;
import app.music.comparator.comparatorascending.album.AlbumComparatorByNumberOfSongsAscending;
import app.music.comparator.comparatordescending.album.AlbumComparatorByAlphabetDescending;
import app.music.comparator.comparatordescending.album.AlbumComparatorByNumberOfSongsDescending;
import app.music.databinding.FragmentAlbumBinding;
import app.music.listener.homefragmentlistener.AlbumFragmentListener;
import app.music.threadhandler.asynctask.OnlineAlbumReloadAsyncTask;
import app.music.ui.screen.onlinemusic.OnlineHomeActivity;
import app.music.utils.ConstantUtil;
import app.music.utils.musicloading.HomeFragmentDataUpdatingUtil;
import app.music.utils.musicloading.LoadMusicUtil;
import app.music.utils.progresscanceling.ProgressCancelingUtils;
import app.music.utils.sort.SortConstantUtils;
import app.music.utils.sort.SortMethodUtils;

public class OnlineAlbumFragment extends BaseFragment<FragmentAlbumBinding>
        implements SwipeRefreshLayout.OnRefreshListener, AlbumFragmentListener {

    private static final String TAG = "AlbumFragment";
    private AlbumAdapter mAlbumRecyclerAdapter;
    private OnlineAlbumReloadAsyncTask<? extends Comparator> albumReloadAsyncTask;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        ((OnlineHomeActivity) context).setMAlbumFragmentListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        ProgressCancelingUtils.INSTANCE.cancelAsyncTask(albumReloadAsyncTask);
        getBinding().refreshlayout.setRefreshing(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getBinding().recyclerview.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_album;
    }

    @Override
    public String getLogTag() {
        return TAG;
    }

    @Override
    public void initView() {
        getBinding().recyclerview.setHasFixedSize(true);
        getBinding().recyclerview.setLayoutManager(
                new GridLayoutManager(getContext(), ConstantUtil.SPAN_COUNT_THREE));
        getBinding().refreshlayout.setOnRefreshListener(this);
    }

    @Override
    public void initData() {
        mAlbumRecyclerAdapter = new AlbumAdapter(new WeakReference<>(getActivity()));
        getBinding().recyclerview.setAdapter(mAlbumRecyclerAdapter);
        reloadData(false);
        mAlbumRecyclerAdapter.updateItems(false, LoadMusicUtil.sOnlineAlbumList);
    }

    @Override
    public void onRefresh() {
        reloadData(true);
    }

    @Override
    public void onAlbumListReload(boolean reloadList, String sortBy, String isAscending) {
        switch (sortBy) {
            case SortConstantUtils.PREF_ALBUM_SORT_BY_ALPHABET:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new AlbumComparatorByAlphabetAscending() :
                                new AlbumComparatorByAlphabetDescending());
                break;
            case SortConstantUtils.PREF_ALBUM_SORT_BY_NUMBER_OF_SONGS:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new AlbumComparatorByNumberOfSongsAscending() :
                                new AlbumComparatorByNumberOfSongsDescending());
                break;
        }
    }

    @Override
    public void onScrollToTop() {
        getBinding().recyclerview.scrollToPosition(0);
    }

    public void reloadData(boolean reloadList) {
        String[] sortState = SortMethodUtils.INSTANCE.getAlbumSortState(new WeakReference<>(getActivity()));
        onAlbumListReload(reloadList, sortState[0], sortState[1]);
    }

    private <C extends Comparator> void reloadList(Boolean reloadMusicList, C comparator) {
        HomeFragmentDataUpdatingUtil.INSTANCE.updateOnlineAlbumList(getActivity(),
                getCompositeDisposable(), mAlbumRecyclerAdapter, getBinding().refreshlayout,
                comparator, ((OnlineHomeActivity) getActivity()).mRetrofit, reloadMusicList);
    }
}
