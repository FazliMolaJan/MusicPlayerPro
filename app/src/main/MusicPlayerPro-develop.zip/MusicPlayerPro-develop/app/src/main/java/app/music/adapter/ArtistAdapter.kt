package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemHomeThirdFragmentBinding
import app.music.diffcallback.ArtistDiffCallBack
import app.music.listener.ArtistFragmentItemClickListener
import app.music.listener.ToolbarScrollFlagListener
import app.music.model.Artist
import app.music.utils.recyclerview.RecyclerViewUtils
import app.music.viewholder.ArtistViewHolder
import java.lang.ref.WeakReference

class ArtistAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<Artist, ArtistViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): ArtistViewHolder {
        return ArtistViewHolder(mActivityReference, binding as ItemHomeThirdFragmentBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
        return object : ArtistFragmentItemClickListener {
            override fun onArtistClick(artist: Artist, isLongClick: Boolean) {
                (activity as ArtistFragmentItemClickListener).onArtistClick(artist, isLongClick)
            }
        }
    }

    override fun getDiffResult(
            isFilter: Boolean, dataList: List<Artist>, newItems: List<Artist>): DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(ArtistDiffCallBack(dataList, newItems), false)
    }

    override fun getLayoutId(): Int = R.layout.item_home_third_fragment

    override fun isContainingFilterPatternItem(item: Artist, filterPattern: String): Boolean {
        return item.artistName.toLowerCase().contains(filterPattern)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        RecyclerViewUtils.setToolbarScrollFlag(recyclerView, mActivityReference)
    }
}
