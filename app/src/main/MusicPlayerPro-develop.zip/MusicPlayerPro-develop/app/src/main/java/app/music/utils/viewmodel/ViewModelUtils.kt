package app.music.utils.viewmodel

import android.app.Activity
import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProviders
import android.support.v4.app.FragmentActivity

object ViewModelUtils {

    inline fun <reified T : ViewModel> getViewModel(activity: Activity): T {
        return ViewModelProviders.of(activity as FragmentActivity).get(T::class.java)
    }
}