package app.music.utils.sort

import android.content.Context
import android.content.SharedPreferences
import app.music.utils.sharepreferences.SharedPrefMethodUtils
import java.lang.ref.WeakReference

object SortMethodUtils {

    private var sEditor: SharedPreferences.Editor? = null

    private fun saveSortState(contextReference: WeakReference<Context>,
                              sortKey: String, sortValue: String,
                              orderKey: String, orderValue: String) {
        if (null == sEditor) {
            sEditor = SharedPrefMethodUtils.getSharedPreferences(contextReference).edit()
        }
        sEditor?.run {
            putString(sortKey, sortValue)
            putString(orderKey, orderValue)
            apply()
        }
    }

    fun saveAlbumSortState(
            contextReference: WeakReference<Context>, sortValue: String, orderValue: String) {
        saveSortState(
                contextReference,
                SortConstantUtils.PREF_ALBUM_SORT,
                sortValue,
                SortConstantUtils.PREF_ALBUM_ORDER_BY,
                orderValue)
    }

    fun saveSongSortState(
            contextReference: WeakReference<Context>, sortValue: String, orderValue: String) {
        saveSortState(
                contextReference,
                SortConstantUtils.PREF_SONG_SORT,
                sortValue,
                SortConstantUtils.PREF_SONG_ORDER_BY,
                orderValue)
    }

    fun saveArtistSortState(
            contextReference: WeakReference<Context>, sortValue: String, orderValue: String) {
        saveSortState(
                contextReference,
                SortConstantUtils.PREF_ARTIST_SORT,
                sortValue,
                SortConstantUtils.PREF_ARTIST_ORDER_BY,
                orderValue)
    }

    fun saveGenreSortState(
            contextReference: WeakReference<Context>, sortValue: String, orderValue: String) {
        saveSortState(
                contextReference,
                SortConstantUtils.PREF_GENRE_SORT,
                sortValue,
                SortConstantUtils.PREF_GENRE_ORDER_BY,
                orderValue)
    }

    fun savePlaylistSortState(
            contextReference: WeakReference<Context>, sortValue: String, orderValue: String) {
        saveSortState(
                contextReference,
                SortConstantUtils.PREF_PLAYLIST_SORT,
                sortValue,
                SortConstantUtils.PREF_PLAYLIST_ORDER_BY,
                orderValue)
    }

    fun getAlbumSortState(contextReference: WeakReference<Context>): Array<String?> {
        with(SharedPrefMethodUtils.getSharedPreferences(contextReference)) {
            val sortState = getString(
                    SortConstantUtils.PREF_ALBUM_SORT, SortConstantUtils.PREF_ALBUM_SORT_BY_ALPHABET)
            val orderState = getString(
                    SortConstantUtils.PREF_ALBUM_ORDER_BY, SortConstantUtils.PREF_ORDER_BY_ASCENDING)
            return arrayOf(sortState, orderState)
        }
    }

    fun getSongSortState(contextReference: WeakReference<Context>): Array<String?> {
        with(SharedPrefMethodUtils.getSharedPreferences(contextReference)) {
            val sortState = getString(
                    SortConstantUtils.PREF_SONG_SORT, SortConstantUtils.PREF_SONG_SORT_BY_ALPHABET)
            val orderState = getString(
                    SortConstantUtils.PREF_SONG_ORDER_BY, SortConstantUtils.PREF_ORDER_BY_ASCENDING)
            return arrayOf(sortState, orderState)
        }
    }

    fun getArtistSortState(contextReference: WeakReference<Context>): Array<String?> {
        with(SharedPrefMethodUtils.getSharedPreferences(contextReference)) {
            val sortState = getString(
                    SortConstantUtils.PREF_ARTIST_SORT, SortConstantUtils.PREF_ARTIST_SORT_BY_ALPHABET)
            val orderState = getString(
                    SortConstantUtils.PREF_ARTIST_ORDER_BY, SortConstantUtils.PREF_ORDER_BY_ASCENDING)
            return arrayOf(sortState, orderState)
        }
    }

    fun getGenreSortState(contextReference: WeakReference<Context>): Array<String?> {
        with(SharedPrefMethodUtils.getSharedPreferences(contextReference)) {
            val sortState = getString(
                    SortConstantUtils.PREF_GENRE_SORT, SortConstantUtils.PREF_GENRE_SORT_BY_ALPHABET)
            val orderState = getString(
                    SortConstantUtils.PREF_GENRE_ORDER_BY, SortConstantUtils.PREF_ORDER_BY_ASCENDING)
            return arrayOf(sortState, orderState)
        }
    }

    fun getFolderSortState(contextReference: WeakReference<Context>): Array<String?> {
        with(SharedPrefMethodUtils.getSharedPreferences(contextReference)) {
            val sortState = getString(
                    SortConstantUtils.PREF_FOLDER_SORT, SortConstantUtils.PREF_FOLDER_SORT_BY_ALPHABET)
            val orderState = getString(
                    SortConstantUtils.PREF_FOLDER_ORDER_BY, SortConstantUtils.PREF_ORDER_BY_ASCENDING)
            return arrayOf(sortState, orderState)
        }
    }

    fun getPlaylistSortState(contextReference: WeakReference<Context>): Array<String?> {
        with(SharedPrefMethodUtils.getSharedPreferences(contextReference)) {
            val sortState = getString(
                    SortConstantUtils.PREF_PLAYLIST_SORT, SortConstantUtils.PREF_PLAYLIST_SORT_BY_ALPHABET)
            val orderState = getString(
                    SortConstantUtils.PREF_PLAYLIST_ORDER_BY, SortConstantUtils.PREF_ORDER_BY_ASCENDING)
            return arrayOf(sortState, orderState)
        }
    }
}
