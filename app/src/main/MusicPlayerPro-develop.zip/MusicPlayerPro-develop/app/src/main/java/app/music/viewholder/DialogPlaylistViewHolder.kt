package app.music.viewholder

import android.app.Activity
import android.content.Context
import android.databinding.ObservableField
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.View
import app.music.R
import app.music.base.BaseViewHolder
import app.music.databinding.ItemDialogPlaylistBinding
import app.music.listener.dialoglistener.DialogAddToPlaylistListener
import app.music.model.Playlist
import java.lang.ref.WeakReference

class DialogPlaylistViewHolder(
        weakReference: WeakReference<Activity>, itemView: ItemDialogPlaylistBinding)
    : BaseViewHolder<Playlist, ItemDialogPlaylistBinding, DialogAddToPlaylistListener>
(weakReference, itemView) {

    var playlistName = ObservableField<String>()

    override fun bindData(dataObject: Playlist) {
        if (mBinding.itemview == null) {
            mBinding.itemview = this
        }
        dataObject.let {
            val context by lazy { mViewHolderWeakReference.get() as Context }
            val defaultValue by lazy { context.getString(R.string.empty_string) }
            setStringObservableFieldValue(context, playlistName, it.playlistName, defaultValue)
        }
    }

    override fun clickItemListener(position: Int, isLongClick: Boolean) {
        mItemClickListener?.onDialogPlaylistClick(mDataList[position].isOnlinePlaylist,
                mDataList[position].createdTime)
    }
}
