package app.music.listener.homefragmentlistener

import app.music.listener.RecyclerScrollToTopListener

interface PlaylistFragmentListener : RecyclerScrollToTopListener {
    fun onPlaylistListReload(reloadList: Boolean, sortBy: String, isAscending: String)
}
