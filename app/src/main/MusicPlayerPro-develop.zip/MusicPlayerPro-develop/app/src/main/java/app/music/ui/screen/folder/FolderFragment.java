package app.music.ui.screen.folder;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;

import java.lang.ref.WeakReference;
import java.util.Comparator;

import app.music.R;
import app.music.adapter.FolderAdapter;
import app.music.threadhandler.asynctask.FolderReloadAsyncTask;
import app.music.base.BaseFragment;
import app.music.comparator.comparatorascending.folder.FolderComparatorByAlphabetAscending;
import app.music.comparator.comparatorascending.folder.FolderComparatorByNumberOfSongsAscending;
import app.music.comparator.comparatordescending.folder.FolderComparatorByAlphabetDescending;
import app.music.comparator.comparatordescending.folder.FolderComparatorByNumberOfSongsDescending;
import app.music.databinding.FragmentFolderBinding;
import app.music.listener.homefragmentlistener.FolderFragmentListener;
import app.music.ui.screen.home.HomeActivity;
import app.music.utils.musicloading.LoadMusicUtil;
import app.music.utils.progresscanceling.ProgressCancelingUtils;
import app.music.utils.recyclerview.RecyclerViewUtils;
import app.music.utils.sort.SortConstantUtils;
import app.music.utils.sort.SortMethodUtils;

public class FolderFragment extends BaseFragment<FragmentFolderBinding>
        implements SwipeRefreshLayout.OnRefreshListener, FolderFragmentListener {

    private static final String TAG = "GenreFragment";
    private FolderAdapter mFolderRecyclerAdapter;
    private FolderReloadAsyncTask<? extends Comparator> mFolderReloadAsyncTask;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        ((HomeActivity) context).setFolderFragmentListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        ProgressCancelingUtils.INSTANCE.cancelAsyncTask(mFolderReloadAsyncTask);
        getBinding().refreshlayout.setRefreshing(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getBinding().recyclerview.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_folder;
    }

    @Override
    public String getLogTag() {
        return TAG;
    }

    @Override
    public void initView() {
        RecyclerViewUtils.INSTANCE.setVerticalLinearLayout(
                getBinding().recyclerview, getContext(), true, true);
        getBinding().refreshlayout.setOnRefreshListener(this);
    }

    @Override
    public void initData() {
        mFolderRecyclerAdapter = new FolderAdapter(new WeakReference<>(getActivity()));
        getBinding().recyclerview.setAdapter(mFolderRecyclerAdapter);
        reloadData(false);
        mFolderRecyclerAdapter.updateItems(false, LoadMusicUtil.sFolderList);
    }

    @Override
    public void onRefresh() {
        reloadData(true);
    }

    @Override
    public void onFolderListReload(boolean reloadList, String sortBy, String isAscending) {
        switch (sortBy) {
            case SortConstantUtils.PREF_FOLDER_SORT_BY_ALPHABET:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new FolderComparatorByAlphabetAscending() :
                                new FolderComparatorByAlphabetDescending());
                break;
            case SortConstantUtils.PREF_FOLDER_SORT_BY_NUMBER_OF_SONGS:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new FolderComparatorByNumberOfSongsAscending() :
                                new FolderComparatorByNumberOfSongsDescending());
                break;
        }
    }

    public void reloadData(boolean reloadList) {
        String[] sortState = SortMethodUtils.INSTANCE.getFolderSortState(new WeakReference<>(getActivity()));
        onFolderListReload(reloadList, sortState[0], sortState[1]);
    }

    private <C extends Comparator> void reloadList(Boolean reloadMusicList, C comparator) {
        mFolderReloadAsyncTask = new FolderReloadAsyncTask<>(
                new WeakReference<>(FolderFragment.this),
                mFolderRecyclerAdapter,
                new WeakReference<>(getBinding().refreshlayout),
                comparator);
        mFolderReloadAsyncTask.execute(reloadMusicList);
    }
}
