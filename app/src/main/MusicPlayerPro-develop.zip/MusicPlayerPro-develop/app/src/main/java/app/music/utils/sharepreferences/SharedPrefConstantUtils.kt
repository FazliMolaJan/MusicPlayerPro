package app.music.utils.sharepreferences

object SharedPrefConstantUtils {

    const val PREF_SHARED_PREFERENCES_NAME = "PREF_SHARED_PREFERENCES_NAME"
}
