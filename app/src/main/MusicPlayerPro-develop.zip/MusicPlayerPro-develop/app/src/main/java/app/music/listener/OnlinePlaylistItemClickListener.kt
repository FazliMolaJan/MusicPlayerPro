package app.music.listener

import android.app.Activity
import android.content.Context
import android.os.SystemClock
import app.music.model.OnlinePlaylist
import app.music.utils.DoubleClickUtils
import app.music.utils.intent.IntentMethodUtils
import app.music.utils.toast.ToastUtil
import app.music.utils.viewmodel.ViewModelUtils
import app.music.viewmodel.BaseHomeActivityViewModel

interface OnlinePlaylistItemClickListener {

    fun onOnlinePlaylistClick(playlist: OnlinePlaylist, isLongClick: Boolean) {
        val mHomeActivityViewModel = ViewModelUtils.getViewModel<BaseHomeActivityViewModel>(this as Activity)
        with(mHomeActivityViewModel) {
            if (!DoubleClickUtils.isDoubleClick(getItemLastClickTime())) {
                setItemLastClickTime(SystemClock.elapsedRealtime())
                if (isLongClick) {
                    ToastUtil.showToast("Album Long click${playlist.playlistName}")
                } else {
                    IntentMethodUtils.launchDetailOnlinePlaylistActivity(
                            this@OnlinePlaylistItemClickListener as Context, playlist)
                }
            } else {
                setItemLastClickTime(SystemClock.elapsedRealtime())
            }
        }
    }
}
