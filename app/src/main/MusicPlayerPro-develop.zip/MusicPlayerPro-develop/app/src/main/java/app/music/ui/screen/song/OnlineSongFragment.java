package app.music.ui.screen.song;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;

import java.lang.ref.WeakReference;
import java.util.Comparator;

import app.music.R;
import app.music.adapter.SongAdapter;
import app.music.threadhandler.asynctask.OnlineSongReloadAsyncTask;
import app.music.base.BaseFragment;
import app.music.comparator.comparatorascending.song.SongComparatorByAlbumAscending;
import app.music.comparator.comparatorascending.song.SongComparatorByAlphabetAscending;
import app.music.comparator.comparatorascending.song.SongComparatorByArtistAscending;
import app.music.comparator.comparatorascending.song.SongComparatorByDateModifiedAscending;
import app.music.comparator.comparatorascending.song.SongComparatorByDurationAscending;
import app.music.comparator.comparatorascending.song.SongComparatorByGenreAscending;
import app.music.comparator.comparatorascending.song.SongComparatorByReleaseYearAscending;
import app.music.comparator.comparatordescending.song.SongComparatorByAlbumDescending;
import app.music.comparator.comparatordescending.song.SongComparatorByAlphabetDescending;
import app.music.comparator.comparatordescending.song.SongComparatorByArtistDescending;
import app.music.comparator.comparatordescending.song.SongComparatorByDateModifiedDescending;
import app.music.comparator.comparatordescending.song.SongComparatorByDurationDescending;
import app.music.comparator.comparatordescending.song.SongComparatorByGenreDescending;
import app.music.comparator.comparatordescending.song.SongComparatorByReleaseYearDescending;
import app.music.databinding.FragmentSongBinding;
import app.music.listener.homefragmentlistener.SongFragmentListener;
import app.music.ui.screen.onlinemusic.OnlineHomeActivity;
import app.music.utils.musicloading.LoadMusicUtil;
import app.music.utils.progresscanceling.ProgressCancelingUtils;
import app.music.utils.recyclerview.RecyclerViewUtils;
import app.music.utils.sort.SortConstantUtils;
import app.music.utils.sort.SortMethodUtils;

public class OnlineSongFragment
        extends BaseFragment<FragmentSongBinding>
        implements SwipeRefreshLayout.OnRefreshListener, SongFragmentListener {

    private static final String TAG = "OnlineSongFragment";
    private SongAdapter mSongRecyclerAdapter;
    private OnlineSongReloadAsyncTask<? extends Comparator> mSongReloadAsyncTask;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        ((OnlineHomeActivity) context).setMSongFragmentListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        ProgressCancelingUtils.INSTANCE.cancelAsyncTask(mSongReloadAsyncTask);
        getBinding().refreshlayout.setRefreshing(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getBinding().recyclerview.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_song;
    }

    @Override
    public String getLogTag() {
        return TAG;
    }

    @Override
    public void initView() {
        RecyclerViewUtils.INSTANCE.setVerticalLinearLayout(getBinding().recyclerview, getContext(), true);
        getBinding().recyclerview.setItemAnimator(new DefaultItemAnimator());
        getBinding().refreshlayout.setOnRefreshListener(this);
    }

    @Override
    public void initData() {
        mSongRecyclerAdapter = new SongAdapter(new WeakReference<>(getActivity()));
        getBinding().recyclerview.setAdapter(mSongRecyclerAdapter);
        reloadData(false);
        mSongRecyclerAdapter.updateItems(false, LoadMusicUtil.sOnlineMusicList);
    }

    @Override
    public void onRefresh() {
        reloadData(true);
    }

    @Override
    public void onSongListReload(boolean reloadList, String sortBy, String isAscending) {
        switch (sortBy) {
            case SortConstantUtils.PREF_SONG_SORT_BY_ALBUM:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new SongComparatorByAlbumAscending() :
                                new SongComparatorByAlbumDescending());
                break;
            case SortConstantUtils.PREF_SONG_SORT_BY_ALPHABET:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new SongComparatorByAlphabetAscending() :
                                new SongComparatorByAlphabetDescending());
                break;
            case SortConstantUtils.PREF_SONG_SORT_BY_ARTIST:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new SongComparatorByArtistAscending() :
                                new SongComparatorByArtistDescending());
                break;
            case SortConstantUtils.PREF_SONG_SORT_BY_DURATION:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new SongComparatorByDurationAscending() :
                                new SongComparatorByDurationDescending());
                break;
            case SortConstantUtils.PREF_SONG_SORT_BY_GENRE:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new SongComparatorByGenreAscending() :
                                new SongComparatorByGenreDescending());
                break;
            case SortConstantUtils.PREF_SONG_SORT_BY_RELEASE_YEAR:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new SongComparatorByReleaseYearAscending() :
                                new SongComparatorByReleaseYearDescending());
                break;
            case SortConstantUtils.PREF_SONG_SORT_BY_DATE_MODIFIED:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new SongComparatorByDateModifiedAscending() :
                                new SongComparatorByDateModifiedDescending());
                break;
        }
    }

//    @Override
//    public void onFilterList(String filterPattern) {
//        mSongRecyclerAdapter.getFilter().filter(filterPattern);
//    }

    @Override
    public void onScrollToTop() {
        getBinding().recyclerview.scrollToPosition(0);
    }

    public void reloadData(boolean reloadList) {
        String[] sortState = SortMethodUtils.INSTANCE.getSongSortState(new WeakReference<>(getActivity()));
        onSongListReload(reloadList, sortState[0], sortState[1]);
    }

    private <C extends Comparator> void reloadList(Boolean reloadMusicList, C comparator) {
        mSongReloadAsyncTask = new OnlineSongReloadAsyncTask<>(
                new WeakReference<>(OnlineSongFragment.this),
                mSongRecyclerAdapter,
                new WeakReference<>(getBinding().refreshlayout),
                comparator);
        mSongReloadAsyncTask.execute(reloadMusicList, true);
    }
}
