package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemDialogOnlinePlaylistBinding
import app.music.diffcallback.DialogOnlinePlaylistDiffCallBack
import app.music.listener.dialoglistener.DialogAddToPlaylistListener
import app.music.model.OnlinePlaylist
import app.music.viewholder.DialogOnlinePlaylistViewHolder
import java.lang.ref.WeakReference
import java.util.*

class DialogOnlinePlaylistAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<OnlinePlaylist, DialogOnlinePlaylistViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): DialogOnlinePlaylistViewHolder {
        return DialogOnlinePlaylistViewHolder(
                mActivityReference, binding as ItemDialogOnlinePlaylistBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
        return object : DialogAddToPlaylistListener {
            override fun onDialogPlaylistClick(isOnlinePlaylist: Boolean,
                                               playlistCreatedTime: Calendar) {
                (activity as DialogAddToPlaylistListener)
                        .onDialogPlaylistClick(isOnlinePlaylist, playlistCreatedTime)
            }
        }
    }

    override fun getDiffResult(
            isFilter: Boolean, dataList: List<OnlinePlaylist>, newItems: List<OnlinePlaylist>)
            : DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(
                DialogOnlinePlaylistDiffCallBack(dataList, newItems),
                false)
    }

    override fun getLayoutId(): Int = R.layout.item_dialog_online_playlist

    override fun isContainingFilterPatternItem(item: OnlinePlaylist, filterPattern: String): Boolean {
        return item.playlistName.toLowerCase().contains(filterPattern)
    }
}
