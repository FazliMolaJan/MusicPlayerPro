package app.music.ui.screen.playlist;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;

import java.lang.ref.WeakReference;
import java.util.Comparator;

import app.music.R;
import app.music.adapter.PlaylistAdapter;
import app.music.base.BaseFragment;
import app.music.comparator.comparatorascending.playlist.offlineplaylist.PlaylistComparatorByAlphabetAscending;
import app.music.comparator.comparatorascending.playlist.offlineplaylist.PlaylistComparatorByCreatedTimeAscending;
import app.music.comparator.comparatorascending.playlist.offlineplaylist.PlaylistComparatorByNumberOfSongsAscending;
import app.music.comparator.comparatordescending.playlist.offlineplaylist.PlaylistComparatorByAlphabetDescending;
import app.music.comparator.comparatordescending.playlist.offlineplaylist.PlaylistComparatorByCreatedTimeDescending;
import app.music.comparator.comparatordescending.playlist.offlineplaylist.PlaylistComparatorByNumberOfSongsDescending;
import app.music.databinding.FragmentPlaylistBinding;
import app.music.listener.homefragmentlistener.PlaylistFragmentListener;
import app.music.ui.screen.home.HomeActivity;
import app.music.utils.musicloading.HomeFragmentDataUpdatingUtil;
import app.music.utils.musicloading.LoadMusicUtil;
import app.music.utils.recyclerview.RecyclerViewUtils;
import app.music.utils.sort.SortConstantUtils;
import app.music.utils.sort.SortMethodUtils;

public class PlaylistFragment extends BaseFragment<FragmentPlaylistBinding>
        implements SwipeRefreshLayout.OnRefreshListener, PlaylistFragmentListener {

    private static final String TAG = "PlaylistFragment";
    private PlaylistAdapter mPlaylistRecyclerAdapter;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        ((HomeActivity) context).setMPlaylistFragmentListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        getBinding().refreshlayout.setRefreshing(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getBinding().recyclerview.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_playlist;
    }

    @Override
    public String getLogTag() {
        return TAG;
    }

    @Override
    public void initView() {
        RecyclerViewUtils.INSTANCE.setVerticalLinearLayout(getBinding().recyclerview, getContext(), true);
        getBinding().refreshlayout.setOnRefreshListener(this);
    }

    @Override
    public void initData() {
        mPlaylistRecyclerAdapter = new PlaylistAdapter(new WeakReference<>(getActivity()));
        getBinding().recyclerview.setAdapter(mPlaylistRecyclerAdapter);
        reloadData(false);
        mPlaylistRecyclerAdapter.updateItems(false, LoadMusicUtil.sPlaylistList);
    }

    @Override
    public void onRefresh() {
        reloadData(true);
    }

    @Override
    public void onPlaylistListReload(boolean reloadList, String sortBy, String isAscending) {
        switch (sortBy) {
            case SortConstantUtils.PREF_PLAYLIST_SORT_BY_ALPHABET:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new PlaylistComparatorByAlphabetAscending() :
                                new PlaylistComparatorByAlphabetDescending());
                break;
            case SortConstantUtils.PREF_PLAYLIST_SORT_BY_CREATED_TIME:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new PlaylistComparatorByCreatedTimeAscending() :
                                new PlaylistComparatorByCreatedTimeDescending());
                break;
            case SortConstantUtils.PREF_PLAYLIST_SORT_BY_NUMBER_OF_SONGS:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new PlaylistComparatorByNumberOfSongsAscending() :
                                new PlaylistComparatorByNumberOfSongsDescending());
                break;
        }
    }

    @Override
    public void onScrollToTop() {
        getBinding().recyclerview.scrollToPosition(0);
    }

    public void reloadData(boolean reloadList) {
        String[] sortState = SortMethodUtils.INSTANCE.getPlaylistSortState(new WeakReference<>(getActivity()));
        onPlaylistListReload(reloadList, sortState[0], sortState[1]);
    }

    private <C extends Comparator> void reloadList(Boolean reloadMusicList, C comparator) {
        HomeFragmentDataUpdatingUtil.INSTANCE.updatePlaylistList(getActivity(), getCompositeDisposable(),
                mPlaylistRecyclerAdapter, getBinding().refreshlayout, comparator, reloadMusicList);
    }
}
