package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemDialogPlaylistBinding
import app.music.diffcallback.DialogPlaylistDiffCallBack
import app.music.listener.dialoglistener.DialogAddToPlaylistListener
import app.music.model.Playlist
import app.music.viewholder.DialogPlaylistViewHolder
import java.lang.ref.WeakReference
import java.util.*

class DialogPlaylistAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<Playlist, DialogPlaylistViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): DialogPlaylistViewHolder {
        return DialogPlaylistViewHolder(mActivityReference, binding as ItemDialogPlaylistBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
//        return object : DialogPlaylistItemClickListener {
//            override fun onDialogPlaylistClick(
//                    isOnlinePlaylist: Boolean, playlistArrayPosition: Int,
//                    playlistCreatedTime: Calendar, isLongClick: Boolean) {
//                (activity as DialogPlaylistItemClickListener)
//                        .onDialogPlaylistClick(isOnlinePlaylist, playlistArrayPosition,
//                                playlistCreatedTime, isLongClick)
//            }
//        }

        return object : DialogAddToPlaylistListener {
            override fun onDialogPlaylistClick(
                    isOnlinePlaylist: Boolean, playlistCreatedTime: Calendar) {
                (activity as DialogAddToPlaylistListener)
                        .onDialogPlaylistClick(isOnlinePlaylist, playlistCreatedTime)
            }
        }
    }

    override fun getDiffResult(
            isFilter: Boolean, dataList: List<Playlist>, newItems: List<Playlist>): DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(
                DialogPlaylistDiffCallBack(dataList, newItems),
                false)
    }

    override fun getLayoutId(): Int = R.layout.item_dialog_playlist

    override fun isContainingFilterPatternItem(item: Playlist, filterPattern: String): Boolean {
        return item.playlistName.toLowerCase().contains(filterPattern)
    }
}
