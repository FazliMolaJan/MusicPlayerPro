package app.music.viewmodel

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Transformations
import android.arch.lifecycle.ViewModel
import app.music.utils.TestLambda

class TransformationViewModel : ViewModel() {
//    private val userLiveData = MutableLiveData<TestLambda.User>()
//    val userAddedData: LiveData<String> = Transformations.map(userLiveData, ::someFunc)
//    private fun someFunc(user: TestLambda.User) = "New user ${user.username} added to database!"
//    fun addNewUser(user: TestLambda.User) = apply { userLiveData.value = user }
}