package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import android.support.v7.widget.RecyclerView
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemOnlineHomeFifthFragmentBinding
import app.music.diffcallback.OnlinePlaylistDiffCallBack
import app.music.listener.OnlinePlaylistItemClickListener
import app.music.model.OnlinePlaylist
import app.music.utils.recyclerview.RecyclerViewUtils
import app.music.viewholder.OnlinePlaylistViewHolder
import java.lang.ref.WeakReference

class OnlinePlaylistAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<OnlinePlaylist, OnlinePlaylistViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): OnlinePlaylistViewHolder {
        return OnlinePlaylistViewHolder(mActivityReference, binding as ItemOnlineHomeFifthFragmentBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
        return object : OnlinePlaylistItemClickListener {
            override fun onOnlinePlaylistClick(playlist: OnlinePlaylist, isLongClick: Boolean) {
                (activity as OnlinePlaylistItemClickListener).onOnlinePlaylistClick(playlist, isLongClick)
            }
        }
    }

    override fun getDiffResult(
            isFilter: Boolean, dataList: List<OnlinePlaylist>, newItems: List<OnlinePlaylist>)
            : DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(OnlinePlaylistDiffCallBack(dataList, newItems), false)
    }

    override fun getLayoutId(): Int = R.layout.item_online_home_fifth_fragment

    override fun isContainingFilterPatternItem(item: OnlinePlaylist, filterPattern: String): Boolean {
        return item.playlistName.toLowerCase().contains(filterPattern)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        RecyclerViewUtils.setToolbarScrollFlag(recyclerView, mActivityReference)
    }
}
