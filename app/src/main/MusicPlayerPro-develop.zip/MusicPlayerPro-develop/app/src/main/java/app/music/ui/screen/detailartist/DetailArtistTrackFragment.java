package app.music.ui.screen.detailartist;


import android.app.Activity;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;

import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;

import app.music.R;
import app.music.adapter.ArtistSongAdapter;
import app.music.base.BaseFragment;
import app.music.comparator.comparatorascending.song.SongComparatorByAlphabetAscending;
import app.music.databinding.FragmentDetailArtistTrackBinding;
import app.music.listener.RecyclerScrollToTopListener;
import app.music.model.Artist;
import app.music.model.BaseMusik;
import app.music.utils.recyclerview.RecyclerViewUtils;

/**
 * A simple {@link Fragment} subclass.
 */
public class DetailArtistTrackFragment extends BaseFragment<FragmentDetailArtistTrackBinding>
        implements RecyclerScrollToTopListener {

    private static final String TAG = "DetailArtistTrackFragment";
    private Artist mArtist;
    private ArtistSongAdapter mRecyclerAdapter;

    public DetailArtistTrackFragment() {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Activity activity = getActivity();
        if (activity != null) {
            mArtist = ((DetailArtistActivity) activity).getMArtist();
            ((DetailArtistActivity) activity).setMDetailArtistTrackFragment(this);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getBinding().recycler.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_detail_artist_track;
    }

    @Override
    public String getLogTag() {
        return TAG;
    }

    @Override
    public void initView() {
        RecyclerViewUtils.INSTANCE.setVerticalLinearLayout(getBinding().recycler, getContext(), true);
        getBinding().recycler.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    public void initData() {
        mRecyclerAdapter = new ArtistSongAdapter(new WeakReference<>(getActivity()));
        getBinding().recycler.setAdapter(mRecyclerAdapter);
//        ArtistSongAdapter songAdapter = new ArtistSongAdapter((DetailArtistActivity) getActivity());
//        mBinding.recycler.setAdapter(songAdapter);
        List<BaseMusik> musicList = mArtist.getMusicList();
        Collections.sort(musicList, new SongComparatorByAlphabetAscending());
//        songAdapter.updateItems(musicList);
        mRecyclerAdapter.updateItems(false, musicList);
    }

    @Override
    public void onScrollToTop() {
        getBinding().recycler.scrollToPosition(0);
    }
}
