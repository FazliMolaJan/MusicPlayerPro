package app.music.base

interface BaseViewModel {

    fun attachView(view: BaseView)

    fun detachView()
}
