package app.music.base;

public interface BaseView {
}
