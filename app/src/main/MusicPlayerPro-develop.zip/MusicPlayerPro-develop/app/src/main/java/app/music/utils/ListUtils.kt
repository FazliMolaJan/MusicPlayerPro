package app.music.utils

object ListUtils {

    fun clearList(list: MutableList<*>?) {
        list?.clear()
    }
}
