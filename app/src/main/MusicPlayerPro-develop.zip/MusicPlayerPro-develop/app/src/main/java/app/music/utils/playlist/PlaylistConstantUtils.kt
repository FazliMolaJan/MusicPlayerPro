package app.music.utils.playlist

object PlaylistConstantUtils {

    const val PREF_ALL_PLAYLISTS = "PREF_ALL_PLAYLISTS"
    const val PREF_ALL_ONLINE_PLAYLISTS = "PREF_ALL_ONLINE_PLAYLISTS"
}
