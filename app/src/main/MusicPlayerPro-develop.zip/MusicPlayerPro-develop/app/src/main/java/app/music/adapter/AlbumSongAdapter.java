package app.music.adapter;

import android.app.Activity;
import android.databinding.ViewDataBinding;
import android.support.v7.util.DiffUtil;

import org.jetbrains.annotations.NotNull;

import java.lang.ref.WeakReference;
import java.util.List;

import app.music.R;
import app.music.base.BaseRecyclerAdapter;
import app.music.databinding.ItemMusicListBinding;
import app.music.diffcallback.SongDiffCallBack;
import app.music.listener.SongItemClickListener;
import app.music.model.BaseMusik;
import app.music.viewholder.AlbumSongViewHolder;

public class AlbumSongAdapter<MusicType extends BaseMusik>
        extends BaseRecyclerAdapter<MusicType, AlbumSongViewHolder> {

    public AlbumSongAdapter(WeakReference<Activity> mActivityWeakReference) {
        super(mActivityWeakReference);
    }

    @Override
    protected AlbumSongViewHolder getViewHolder(ViewDataBinding binding) {
        return new AlbumSongViewHolder(mActivityReference, (ItemMusicListBinding) binding);
    }

    @Override
    protected Object getItemClickListener(Activity activity) {
        return new SongItemClickListener() {
            @Override
            public <MusicType extends BaseMusik> void onSongClick(int position, @NotNull List<? extends MusicType> musicList, boolean isLongClick) {
                ((SongItemClickListener) activity).onSongClick(position, musicList, isLongClick);
            }
        };
    }

    @Override
    protected DiffUtil.DiffResult getDiffResult(
            boolean isFilter, List<MusicType> dataList, List<MusicType> newItems) {
        return DiffUtil.calculateDiff(new SongDiffCallBack(dataList, newItems), false);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.item_music_list;
    }

    @Override
    protected boolean isContainingFilterPatternItem(BaseMusik item, String filterPattern) {
        return item.getTitle().toLowerCase().contains(filterPattern);
    }
}
