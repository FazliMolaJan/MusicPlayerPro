package app.music.listener

interface RecyclerScrollToTopListener {
    fun onScrollToTop()
}