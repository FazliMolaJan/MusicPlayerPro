package app.music.viewmodel

import android.content.Context
import android.databinding.ObservableBoolean
import app.music.base.BaseNormalViewModel
import app.music.base.contract.SettingActivityContract
import app.music.ui.screen.setting.SettingActivity
import app.music.utils.theme.ThemeConstantUtils
import app.music.utils.theme.ThemeMethodUtils
import java.lang.ref.WeakReference


class SettingActivityViewModel
    : BaseNormalViewModel<SettingActivity>(), SettingActivityContract.ViewModel {

    override val mIsDarkModeEnabled = ObservableBoolean()

    fun checkDarkMode() {
        mIsDarkModeEnabled.set(
                when (ThemeMethodUtils
                        .getCurrentThemeMode(WeakReference((mView as Context).applicationContext))) {
                    ThemeConstantUtils.PREF_DARK_MODE -> true
                    ThemeConstantUtils.PREF_LIGHT_MODE -> false
                    else -> true
                }
        )
    }
}