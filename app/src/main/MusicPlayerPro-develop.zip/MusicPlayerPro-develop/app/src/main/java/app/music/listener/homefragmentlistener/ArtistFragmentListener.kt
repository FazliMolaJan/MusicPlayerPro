package app.music.listener.homefragmentlistener

import app.music.listener.RecyclerScrollToTopListener

interface ArtistFragmentListener : RecyclerScrollToTopListener {
    fun onArtistListReload(reloadList: Boolean, sortBy: String, isAscending: String)
}
