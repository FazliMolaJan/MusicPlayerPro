package app.music.utils.favorite

object FavoriteConstantUtils {

    const val PREF_FAVORITE_LIST = "PREF_FAVORITE_LIST"
}
