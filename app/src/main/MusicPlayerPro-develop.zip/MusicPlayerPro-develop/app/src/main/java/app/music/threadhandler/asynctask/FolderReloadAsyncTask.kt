package app.music.threadhandler.asynctask

import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import app.music.adapter.FolderAdapter
import app.music.base.BaseReloadListAsyncTask
import app.music.model.Folder
import app.music.utils.musicloading.LoadMusicUtil
import java.lang.ref.WeakReference
import java.util.*

class FolderReloadAsyncTask<C : Comparator<in Folder>>(
        fragmentReference: WeakReference<Fragment>, recyclerAdapter: FolderAdapter,
        refreshLayoutReference: WeakReference<SwipeRefreshLayout>, comparator: C)
    : BaseReloadListAsyncTask<Folder, C, FolderAdapter>(
        fragmentReference, recyclerAdapter, refreshLayoutReference, comparator) {

    override fun reloadTypeList() = LoadMusicUtil.getFolder()

    override fun getTypeList(): List<Folder> = LoadMusicUtil.sFolderList
}
