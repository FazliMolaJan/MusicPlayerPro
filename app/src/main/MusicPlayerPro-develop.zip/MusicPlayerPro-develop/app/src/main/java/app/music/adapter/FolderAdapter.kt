package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import android.support.v7.widget.RecyclerView
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemHomeSixthFragmentBinding
import app.music.diffcallback.FolderDiffCallBack
import app.music.listener.FolderItemClickListener
import app.music.model.Folder
import app.music.utils.recyclerview.RecyclerViewUtils
import app.music.viewholder.FolderViewHolder
import java.lang.ref.WeakReference

class FolderAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<Folder, FolderViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): FolderViewHolder {
        return FolderViewHolder(mActivityReference, binding as ItemHomeSixthFragmentBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
        return object : FolderItemClickListener {
            override fun onFolderClick(folder: Folder, isLongClick: Boolean) {
                (activity as FolderItemClickListener).onFolderClick(folder, isLongClick)
            }
        }
    }

    override fun getDiffResult(
            isFilter: Boolean, dataList: List<Folder>, newItems: List<Folder>): DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(FolderDiffCallBack(dataList, newItems), false)
    }

    override fun getLayoutId(): Int = R.layout.item_home_sixth_fragment

    override fun isContainingFilterPatternItem(item: Folder, filterPattern: String): Boolean {
        return item.folderName.toLowerCase().contains(filterPattern)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        RecyclerViewUtils.setToolbarScrollFlag(recyclerView, mActivityReference)
    }
}
