package app.music.ui.screen.album;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.text.TextUtils;
import android.util.Log;

import org.jetbrains.annotations.Nullable;

import java.lang.ref.WeakReference;
import java.util.Comparator;

import app.music.R;
import app.music.adapter.AlbumAdapter;
import app.music.base.BaseFragment;
import app.music.comparator.comparatorascending.album.AlbumComparatorByAlphabetAscending;
import app.music.comparator.comparatorascending.album.AlbumComparatorByNumberOfSongsAscending;
import app.music.comparator.comparatordescending.album.AlbumComparatorByAlphabetDescending;
import app.music.comparator.comparatordescending.album.AlbumComparatorByNumberOfSongsDescending;
import app.music.databinding.FragmentAlbumBinding;
import app.music.listener.homefragmentlistener.AlbumFragmentListener;
import app.music.ui.screen.home.HomeActivity;
import app.music.utils.ConstantUtil;
import app.music.utils.musicloading.HomeFragmentDataUpdatingUtil;
import app.music.utils.musicloading.LoadMusicUtil;
import app.music.utils.sort.SortConstantUtils;
import app.music.utils.sort.SortMethodUtils;
import app.music.viewmodel.HomeActivityViewModel;

public class AlbumFragment extends BaseFragment<FragmentAlbumBinding>
        implements SwipeRefreshLayout.OnRefreshListener, AlbumFragmentListener {

    private static final String TAG = "AlbumFragment";
    private AlbumAdapter mAlbumRecyclerAdapter;
    private HomeActivityViewModel mHomeActivityViewModel;
    private String mLastSearchingAlbum = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        ((HomeActivity) context).setMAlbumFragmentListener(this);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHomeActivityViewModel = ViewModelProviders.of(getActivity()).get(HomeActivityViewModel.class);

        mHomeActivityViewModel.getMIsSearching().observe(
                this,
                searching -> {
                    Log.i(TAG, "onCreate: searching changed");
                    if (getMIsVisibleToUser()) {
                        Log.i(TAG, "onCreate: searching changed and visible to user");
                        if (searching != null && searching) {
                            Log.i(TAG, "onCreate: searching changed and visible to user and searching");
                            mAlbumRecyclerAdapter.getFilter().filter(mHomeActivityViewModel.getSearchingText());
                            Log.i(TAG, "onCreate: searching changed and visible to user and searching" + mHomeActivityViewModel.getSearchingText());
                        } else {
                            Log.i(TAG, "onCreate: searching changed and visible to user and not searching");
                            reloadData(false);
                        }
                    }
                }
        );
    }

    @Override
    public void onPause() {
        super.onPause();
        getBinding().refreshlayout.setRefreshing(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getBinding().recyclerview.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_album;
    }

    @Override
    public String getLogTag() {
        return TAG;
    }

    @Override
    public void initView() {
        getBinding().recyclerview.setHasFixedSize(true);
        getBinding().recyclerview.setLayoutManager(
                new GridLayoutManager(getContext(), ConstantUtil.SPAN_COUNT_THREE));
        getBinding().refreshlayout.setOnRefreshListener(this);
    }

    @Override
    public void initData() {
        mAlbumRecyclerAdapter = new AlbumAdapter(new WeakReference<>(getActivity()));
        getBinding().recyclerview.setAdapter(mAlbumRecyclerAdapter);
        reloadData(false);
//        mAlbumRecyclerAdapter.updateItems(false, LoadMusicUtil.sAlbumList);
    }

    @Override
    public void onRefresh() {
        reloadData(true);
    }

    @Override
    public void onAlbumListReload(boolean reloadList, String sortBy, String isAscending) {
        switch (sortBy) {
            case SortConstantUtils.PREF_ALBUM_SORT_BY_ALPHABET:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new AlbumComparatorByAlphabetAscending() :
                                new AlbumComparatorByAlphabetDescending());
                break;
            case SortConstantUtils.PREF_ALBUM_SORT_BY_NUMBER_OF_SONGS:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new AlbumComparatorByNumberOfSongsAscending() :
                                new AlbumComparatorByNumberOfSongsDescending());
                break;
        }
    }

    @Override
    public void onScrollToTop() {
        getBinding().recyclerview.scrollToPosition(0);
    }

    @Override
    public void onVisible() {
        super.onVisible();
        if (mHomeActivityViewModel.getSearching()) {
            Log.i(TAG, "onVisible: mLastSearchingAlbum!=null and searching");
            if (TextUtils.isEmpty(mHomeActivityViewModel.getSearchingText())) {
                Log.i(TAG, "onVisible: mLastSearchingAlbum!=null and searching and searching text not empty");
                reloadData(false);
            } else {
                Log.i(TAG, "onVisible: mLastSearchingAlbum!=null and searching and searching text not empty");
                if (mLastSearchingAlbum == null || !mLastSearchingAlbum.equals(mHomeActivityViewModel.getSearchingText())) {
                    Log.i(TAG, "onVisible: mLastSearchingAlbum!=null and searching and searching text different");
                    mAlbumRecyclerAdapter.getFilter().filter(mHomeActivityViewModel.getSearchingText());
                }
            }
        } else {
            Log.i(TAG, "onVisible: not searching");
            if (mLastSearchingAlbum != null) {
                Log.i(TAG, "onVisible: not searching and mLastSearchingAlbum != null");
                reloadData(false);
            }
        }
    }

    @Override
    public void onInVisible() {
        super.onInVisible();
        mLastSearchingAlbum = mHomeActivityViewModel.getSearchingText();
        Log.i(TAG, "onInVisible: on invisible and get searching text" + mLastSearchingAlbum);
    }

    public void reloadData(boolean reloadList) {
        String[] sortState = SortMethodUtils.INSTANCE.getAlbumSortState(new WeakReference<>(getActivity()));
        onAlbumListReload(reloadList, sortState[0], sortState[1]);
    }

    private <C extends Comparator> void reloadList(boolean reloadMusicList, C comparator) {
        HomeFragmentDataUpdatingUtil.INSTANCE.updateAlbumList(getActivity(), getCompositeDisposable(),
                mAlbumRecyclerAdapter, binding.refreshlayout, comparator, reloadMusicList);
    }
}
