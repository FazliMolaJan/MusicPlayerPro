package app.music.base

import android.databinding.ViewDataBinding


abstract class BaseMVVMActivity<T : ViewDataBinding, VM : BaseViewModel>
    : BaseActivity<T>(), BaseView {

    protected lateinit var mViewModel: VM

    override fun onViewCreated() {
        super.onViewCreated()
        mViewModel = getViewModel()
        mViewModel.attachView(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        mViewModel.detachView()
    }

    abstract fun getViewModel(): VM
}
