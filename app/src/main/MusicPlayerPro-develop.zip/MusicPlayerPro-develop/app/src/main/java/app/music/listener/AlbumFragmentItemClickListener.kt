package app.music.listener

import android.app.Activity
import android.content.Context
import android.os.SystemClock
import app.music.model.Album
import app.music.utils.DoubleClickUtils
import app.music.utils.intent.IntentMethodUtils
import app.music.utils.toast.ToastUtil
import app.music.utils.viewmodel.ViewModelUtils
import app.music.viewmodel.BaseHomeActivityViewModel

interface AlbumFragmentItemClickListener {

    fun onAlbumClick(album: Album, isLongClick: Boolean) {
        val mHomeActivityViewModel = ViewModelUtils.getViewModel<BaseHomeActivityViewModel>(this as Activity)
        with(mHomeActivityViewModel) {
            if (!DoubleClickUtils.isDoubleClick(getItemLastClickTime())) {
                setItemLastClickTime(SystemClock.elapsedRealtime())
                if (isLongClick) {
                    ToastUtil.showToast("Album Long click${album.albumName}")
                } else {
                    IntentMethodUtils.launchDetailAlbumActivity(
                            this@AlbumFragmentItemClickListener as Context, album)
                }
            } else {
                setItemLastClickTime(SystemClock.elapsedRealtime())
            }
        }
    }
}
