package app.music.base;

public class BaseModelView {
}
