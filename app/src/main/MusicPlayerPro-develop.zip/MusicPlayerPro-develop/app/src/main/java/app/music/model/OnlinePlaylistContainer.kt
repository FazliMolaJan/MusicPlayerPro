package app.music.model

class OnlinePlaylistContainer(var playlistList: List<OnlinePlaylist>?)
