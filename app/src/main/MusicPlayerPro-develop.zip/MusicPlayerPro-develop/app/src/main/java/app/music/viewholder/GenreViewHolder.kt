package app.music.viewholder

import android.app.Activity
import android.content.Context
import android.databinding.ObservableField
import app.music.R
import app.music.base.BaseViewHolder
import app.music.databinding.ItemHomeFourthFragmentBinding
import app.music.listener.GenreFragmentItemClickListener
import app.music.model.Genre
import java.lang.ref.WeakReference

class GenreViewHolder(
        weakReference: WeakReference<Activity>, itemView: ItemHomeFourthFragmentBinding)
    : BaseViewHolder<Genre, ItemHomeFourthFragmentBinding, GenreFragmentItemClickListener>
(weakReference, itemView) {

    var genre = ObservableField<String>()

    override fun bindData(dataObject: Genre) {
        if (mBinding.itemview == null) {
            mBinding.itemview = this
        }
        dataObject.let {
            val context by lazy { mViewHolderWeakReference.get() as Context }
            val defaultValue by lazy { context.getString(R.string.empty_string) }
            setStringObservableFieldValue(context, genre, it.genre, defaultValue)
        }
    }

    override fun clickItemListener(position: Int, isLongClick: Boolean) {
        mItemClickListener?.onGenreClick(mDataList[position], isLongClick)
    }
}
