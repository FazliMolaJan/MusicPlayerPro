package app.music.listener.homefragmentlistener

interface FolderFragmentListener {

    fun onFolderListReload(reloadList: Boolean, sortBy: String, isAscending: String)

}
