package app.music.base.contract

import android.databinding.ObservableBoolean
import app.music.base.BaseView
import app.music.base.BaseViewModel

interface SettingActivityContract {

    interface View : BaseView {

    }

    interface ViewModel : BaseViewModel {
        val mIsDarkModeEnabled: ObservableBoolean
    }
}