package app.music.ui.screen.splash

import android.Manifest
import android.annotation.TargetApi
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.Menu
import app.music.base.BaseMVVMActivity
import app.music.base.contract.SplashActivityContract
import app.music.databinding.ActivitySplashBinding
import app.music.viewmodel.SplashActivityViewModel
import com.karumi.dexter.PermissionToken
import javax.inject.Inject


/**
 * Created by jacky on 3/23/18.
 */

class SplashActivity : BaseMVVMActivity<ActivitySplashBinding, SplashActivityViewModel>(),
        SplashActivityContract.View {

    @Inject
    override lateinit var mHandler: Handler
    override var isOnPausing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mViewModel.loadMusic()
        //        SharedPrefMethodUtils.deleteAllPlaylists(new WeakReference<>(this));
    }

    override fun onResume() {
        super.onResume()
        mViewModel.requestStoragePermission(this, packageName)
        isOnPausing = false
    }

    override fun onPause() {
        super.onPause()
        isOnPausing = true
    }

    override fun onDestroy() {
        super.onDestroy()
        mHandler.removeCallbacksAndMessages(null)
    }

    override fun initInject() = activityComponent.inject(this)

    override fun getViewModel(): SplashActivityViewModel = SplashActivityViewModel()

    override fun getLayoutId(): Int = 0
//        return R.layout.activity_splash;

    override fun getLogTag(): String = TAG

    override fun getOptionMenuId(): Int = 0

    override fun createOptionMenu(menu: Menu) {

    }

    override fun initView() {

    }

    override fun initData() {

    }

//    override fun onRequestPermissionsResult(
//            requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
//        when (requestCode) {
//            ConstantUtil.MY_PERMISSION_REQUEST -> {
//                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
//                            == PackageManager.PERMISSION_GRANTED) {
//                        ToastUtil.showToast(getString(R.string.permission_granted))
//                        getListMusic()
//                    }
//                } else {
//                    ToastUtil.showToast(getString(R.string.no_permission_granted))
//                    finish()
//                }
//            }
//        }
//    }

//    private fun checkPermission() {
//        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
//                != PackageManager.PERMISSION_GRANTED) {
//            if (ActivityCompat.shouldShowRequestPermissionRationale(
//                            this,
//                            Manifest.permission.READ_EXTERNAL_STORAGE)) {
//                ActivityCompat.requestPermissions(
//                        this,
//                        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
//                        ConstantUtil.MY_PERMISSION_REQUEST)
//            } else {
//                ActivityCompat.requestPermissions(
//                        this,
//                        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
//                        ConstantUtil.MY_PERMISSION_REQUEST)
//            }
//        } else {
//            getListMusic()
//            getPlaylistList()
//            getOnlinePlaylistList()
//            getFavoriteList()
//        }
//        requestStoragePermission(this, packageName)
//    }

//    private fun requestStoragePermission(activity: Activity, packageName: String) {
//        Dexter.withActivity(activity)
//                .withPermissions(
//                        Manifest.permission.READ_EXTERNAL_STORAGE,
//                        Manifest.permission.INTERNET,
//                        Manifest.permission.CAMERA)
//                .withListener(object : MultiplePermissionsListener {
//                    override fun onPermissionsChecked(report: MultiplePermissionsReport) {
//                        var permissionName: String
//                        var message: String
////                        if (report.areAllPermissionsGranted()) {
////                            getListMusic()
////                            getPlaylistList()
////                            getOnlinePlaylistList()
////                            getFavoriteList()
////                        } else {
//                        for (deniedPermission in report.deniedPermissionResponses) {
//                            when (deniedPermission.permissionName) {
//                                Manifest.permission.READ_EXTERNAL_STORAGE -> {
//                                    permissionName = "STORAGE"
//                                    message = "load offline music"
//                                    showSettingsDialog(activity, packageName, permissionName, message, true)
////                                        requestStoragePermission()
//                                }
////                                    Manifest.permission.WRITE_EXTERNAL_STORAGE -> {
////                                        message = "to load offline music"
////                                    }
//                                Manifest.permission.INTERNET -> {
//                                    permissionName = "Internet"
//                                    message = "load online music"
//                                }
//                                Manifest.permission.CAMERA -> {
//                                    permissionName = "CAMERA"
//                                    message = "take photo"
//                                }
//                            }
//                        }
//                        for (grantedPermission in report.grantedPermissionResponses) {
//                            when (grantedPermission.permissionName) {
//                                Manifest.permission.READ_EXTERNAL_STORAGE -> {
//                                    mStoragePermissionGranted = true
//                                }
////                                    Manifest.permission.WRITE_EXTERNAL_STORAGE -> {
////                                        message = "to load offline music"
////                                    }
//                                Manifest.permission.INTERNET -> {
//                                }
//                                Manifest.permission.CAMERA -> {
//                                }
//                            }
//                        }
////                        }
//                    }
//
//                    override fun onPermissionRationaleShouldBeShown(permissions: MutableList<PermissionRequest>?, token: PermissionToken?) {
//                        token?.continuePermissionRequest()
//                    }
//                }).withErrorListener { ToastUtil.showToast("Error occurred! ") }
//                .onSameThread()
//                .check()
//    }

    fun showPermissionDenied(permission: String, isPermanentlyDenied: Boolean) {
        when (permission) {
            Manifest.permission.READ_EXTERNAL_STORAGE -> {

            }
            Manifest.permission.WRITE_EXTERNAL_STORAGE -> {

            }
            Manifest.permission.INTERNET -> {

            }
            else -> throw RuntimeException("No feedback view for this permission")
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    fun showPermissionRationale(context: Context, token: PermissionToken) {

    }

//    fun requestStoragePermission(): Boolean {
//        var storagePermissionGranted = false
//
//        Dexter.withActivity(this)
//                .withPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
//                .withListener(object : PermissionListener {
//                    override fun onPermissionGranted(response: PermissionGrantedResponse?) {
//                        storagePermissionGranted = true
//                    }
//
//                    override fun onPermissionDenied(response: PermissionDeniedResponse?) {
//                        if (showSettingsDialog(this@SplashActivity, packageName, "Storage", "load offline music")) {
//                            showSettingsDialog(this@SplashActivity, packageName, "Storage", "load offline music")
//                        }
//                    }
//
//                    override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest?, token: PermissionToken?) {
//                        token?.continuePermissionRequest()
//                    }
//                })
//                .check()
//        return storagePermissionGranted
//    }

//    private fun showSettingsDialog(context: Context, packageName: String, permissionName: String,
//                                   message: String): Boolean {
//        var requestPermissionIsNotCancelled = false
//
//        val builder = AlertDialog.Builder(context)
//        builder.setTitle("Need Permissions")
//        builder.setMessage("This app needs $permissionName permission to $message. You can grant them in app settings.")
//        builder.setPositiveButton("GOTO SETTINGS", DialogInterface.OnClickListener { dialog, which ->
//            dialog.cancel()
//            openSettings(context as Activity, packageName)
//            requestPermissionIsNotCancelled = true
//        })
//        builder.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which ->
//            dialog.cancel()
//            requestPermissionIsNotCancelled = false
//        })
//        builder.show()
//        return requestPermissionIsNotCancelled
//    }

//    private fun showSettingsDialog(context: Context, packageName: String, permissionName: String,
//                                   message: String, isMustBeEnabledPermission: Boolean) {
//
//        val builder = AlertDialog.Builder(context)
//        builder.setTitle("Need Permissions")
//        builder.setMessage(
//                (if (isMustBeEnabledPermission) "$permissionName permission must be enabled "
//                else "This app needs $permissionName permission ")
//                        + "to $message. You can grant permission in APP SETTINGS -> PERMISSION.")
//        builder.setPositiveButton("GOTO APP SETTINGS", DialogInterface.OnClickListener { dialog, which ->
//            dialog.cancel()
//            openSettings(context as Activity, packageName)
//            mPermissionRequested = false
//        })
//        if (!isMustBeEnabledPermission) {
//            builder.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which ->
//                dialog.cancel()
//            })
//        }
//        builder.show()
//    }

//    private fun openSettings(activity: Activity, packageName: String) {
//        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//        val uri = Uri.fromParts("package", packageName, null)
//        intent.data = uri
////        ActivityCompat.startActivityForResult(activity, intent, 101, null)
//        startActivity(intent)
//    }

//    private fun exitApplication() {
//        if (Build.VERSION.SDK_INT in 16..20) {
//            finishAffinity()
//        } else if (Build.VERSION.SDK_INT >= 21) {
//            finishAndRemoveTask()
//        }
//    }

//    private fun getAllMusicList() {
//        val onlineAllSongRequest = OneTimeWorkRequest
//                .Builder(OnlineMusicWorker::class.java).build()
//        val onlineAlbumListRequest = OneTimeWorkRequest
//                .Builder(OnlineAlbumListWorker::class.java).build()
//        val onlineArtistListRequest = OneTimeWorkRequest
//                .Builder(OnlineArtistListWorker::class.java).build()
//        val onlineGenreListRequest = OneTimeWorkRequest
//                .Builder(OnlineGenreListWorker::class.java).build()
//        val onlinePlaylistListRequest = OneTimeWorkRequest
//                .Builder(OnlinePlaylistListWorker::class.java).build()
//
//        val offlineAllSongRequest = OneTimeWorkRequest
//                .Builder(OfflineMusicWorker::class.java).build()
//        val offlineAlbumListRequest = OneTimeWorkRequest
//                .Builder(OfflineAlbumListWorker::class.java).build()
//        val offlineArtistListRequest = OneTimeWorkRequest
//                .Builder(OfflineArtistListWorker::class.java).build()
//        val offlineGenreListRequest = OneTimeWorkRequest
//                .Builder(OfflineGenreListWorker::class.java).build()
//        val offlinePlaylistListRequest = OneTimeWorkRequest
//                .Builder(OfflinePlaylistListWorker::class.java).build()
//        val offlineFolderListRequest = OneTimeWorkRequest
//                .Builder(OfflineFolderListWorker::class.java).build()
//        val offlineFavoriteListRequest = OneTimeWorkRequest
//                .Builder(OfflineFavortieListWorker::class.java).build()
//
//        val onlineMusicChain = WorkManager.getInstance()
//                .beginWith(onlineAllSongRequest)
//                .then(listOf(
//                        onlineAlbumListRequest,
//                        onlineArtistListRequest,
//                        onlineGenreListRequest,
//                        onlinePlaylistListRequest))
//        val offlineMusicChain = WorkManager.getInstance()
//                .beginWith(offlineAllSongRequest)
//                .then(listOf(
//                        offlineAlbumListRequest,
//                        offlineArtistListRequest,
//                        offlineGenreListRequest,
//                        offlinePlaylistListRequest,
//                        offlineFolderListRequest,
//                        offlineFavoriteListRequest))
//        WorkContinuation
//                .combine(listOf(onlineMusicChain, offlineMusicChain))
//                .then(mLoadingMusicDoneWorkRequest)
//                .enqueue()
//    }

    companion object {

        private const val TAG = "SplashActivity"
    }
}
