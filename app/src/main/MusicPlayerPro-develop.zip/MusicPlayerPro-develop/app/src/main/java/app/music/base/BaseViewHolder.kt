package app.music.base

import android.app.Activity
import android.content.Context
import android.databinding.ObservableField
import android.databinding.ViewDataBinding
import android.media.MediaMetadataRetriever
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.View
import java.lang.ref.WeakReference
import java.util.*

abstract class BaseViewHolder<T, B : ViewDataBinding, L>(
        protected var mViewHolderWeakReference: WeakReference<Activity>,
        protected var mBinding: B)
    : RecyclerView.ViewHolder(mBinding.root), View.OnClickListener, View.OnLongClickListener {

    protected lateinit var mDataList: MutableList<T>
    protected var mItemClickListener: L? = null
    protected var mMetadataRetriever = MediaMetadataRetriever()

    init {
        with(mBinding.root) {
            setOnClickListener(this@BaseViewHolder)
            setOnLongClickListener(this@BaseViewHolder)
        }
    }

    override fun onClick(v: View) {
        clickItem(false)
    }

    override fun onLongClick(v: View): Boolean {
        clickItem(true)
        return true
    }

    abstract fun bindData(dataObject: T)

    open fun clickItem(isLongClick: Boolean) {
        val position by lazy { adapterPosition }
        if (mItemClickListener == null || position == RecyclerView.NO_POSITION) return
        clickItemListener(position, isLongClick)
    }

    open fun setStringObservableFieldValue(
            context: Context, observableField: ObservableField<String>, value: String,
            defaultValue: String) {
        observableField.set(
                if (TextUtils.isEmpty(value)) defaultValue
                else value
        )
    }

    open fun clickItemListener(position: Int, isLongClick: Boolean) {

    }

    fun setDataList(dataList: MutableList<T>) {
        this.mDataList = ArrayList(dataList)
    }

    fun setItemClickListener(itemClickListener: L) {
        this.mItemClickListener = itemClickListener
    }

    companion object {
        private val TAG = "BaseViewHolder"
    }
}
