package app.music.base.contract

interface BaseBottomProgressActivityContract {

    interface View {
        fun loadLastState()
    }

    interface ViewModel {

    }
}