package app.music.viewmodel

import android.Manifest
import android.app.Activity
import android.arch.lifecycle.LifecycleOwner
import android.arch.lifecycle.Observer
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.support.v7.app.AlertDialog
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkContinuation
import androidx.work.WorkInfo
import androidx.work.WorkManager
import app.music.base.BaseNormalViewModel
import app.music.base.contract.SplashActivityContract
import app.music.threadhandler.workmanager.*
import app.music.ui.screen.splash.SplashActivity
import app.music.utils.WorkerUtils
import app.music.utils.intent.IntentMethodUtils
import app.music.utils.musicloading.LoadMusicUtil
import app.music.utils.toast.ToastUtil
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener

class SplashActivityViewModel
    : BaseNormalViewModel<SplashActivity>(), SplashActivityContract.ViewModel {

    private lateinit var mLoadingMusicDoneWorkRequest: OneTimeWorkRequest
    private var mStoragePermissionGranted = false
    private var mMusicLoadingStarted = false
    private var mPermissionRequested = false

    override fun requestStoragePermission(activity: Activity, packageName: String) {
        if (!mPermissionRequested) {
            mPermissionRequested = true
            Dexter.withActivity(activity)
                    .withPermissions(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.INTERNET,
                            Manifest.permission.CAMERA)
                    .withListener(object : MultiplePermissionsListener {
                        override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                            var permissionName: String
                            var message: String
//                        if (report.areAllPermissionsGranted()) {
//                            getListMusic()
//                            getPlaylistList()
//                            getOnlinePlaylistList()
//                            getFavoriteList()
//                        } else {
                            for (deniedPermission in report.deniedPermissionResponses) {
                                when (deniedPermission.permissionName) {
                                    Manifest.permission.READ_EXTERNAL_STORAGE -> {
                                        permissionName = "STORAGE"
                                        message = "load offline music"
                                        showSettingsDialog(activity, packageName, permissionName, message, true)
//                                        requestStoragePermission()
                                    }
//                                    Manifest.permission.WRITE_EXTERNAL_STORAGE -> {
//                                        message = "to load offline music"
//                                    }
                                    Manifest.permission.INTERNET -> {
                                        permissionName = "Internet"
                                        message = "load online music"
                                    }
                                    Manifest.permission.CAMERA -> {
                                        permissionName = "CAMERA"
                                        message = "take photo"
                                    }
                                }
                            }
                            for (grantedPermission in report.grantedPermissionResponses) {
                                when (grantedPermission.permissionName) {
                                    Manifest.permission.READ_EXTERNAL_STORAGE -> {
                                        mStoragePermissionGranted = true
                                    }
//                                    Manifest.permission.WRITE_EXTERNAL_STORAGE -> {
//                                        message = "to load offline music"
//                                    }
                                    Manifest.permission.INTERNET -> {
                                    }
                                    Manifest.permission.CAMERA -> {
                                    }
                                }
                            }
//                        }
                        }

                        override fun onPermissionRationaleShouldBeShown(
                                permissions: MutableList<PermissionRequest>?,
                                token: PermissionToken?) {
                            token?.continuePermissionRequest()
                        }
                    }).withErrorListener { ToastUtil.showToast("Error occurred! ") }
                    .onSameThread()
                    .check()
        }
    }

    override fun loadMusic() {
        LoadMusicUtil.sLoadOnlineMusicStatus = ""
        mLoadingMusicDoneWorkRequest = OneTimeWorkRequest
                .Builder(LoadingMusicDoneWorker::class.java).build()
        WorkManager.getInstance()
                .getWorkInfoByIdLiveData(mLoadingMusicDoneWorkRequest.id)
                .observe(
                        mView as LifecycleOwner,
                        Observer<WorkInfo> { workInfo ->
                            if (workInfo != null && workInfo.state == WorkInfo.State.SUCCEEDED) {
                                when (LoadMusicUtil.sLoadOnlineMusicStatus) {
                                    LoadMusicUtil.LOAD_ONLINE_MUSIC_SUCCEED -> {
                                        if (LoadMusicUtil.sMusicList.size > 0) {
                                            if (!(mView as SplashActivity).isOnPausing) {
                                                IntentMethodUtils.launchHomeActivity(
                                                        mView as Context, true)
                                            }
                                        } else {
                                            ToastUtil.showToast("there's no song in your device")
                                            exitApplication()
                                        }
                                    }

                                    LoadMusicUtil.LOAD_ONLINE_MUSIC_FAILED -> {
                                        if (!(mView as SplashActivity).isOnPausing) {
                                            ToastUtil.showToast("online music load failed")
                                            IntentMethodUtils.launchHomeActivity(
                                                    mView as Context, true)
                                        }
                                    }
                                }
                            }
                        })

        with(mView as SplashActivity) {
            mHandler.post(object : Runnable {
                override fun run() {
                    if (mStoragePermissionGranted && !mMusicLoadingStarted) {
                        mMusicLoadingStarted = true
                        getAllMusicList()
                        mHandler.removeCallbacksAndMessages(null)
                    }
                    mHandler.postDelayed(this, 100)
                }
            })
        }
    }

    private fun showSettingsDialog(context: Context, packageName: String, permissionName: String,
                                   message: String, isMustBeEnabledPermission: Boolean) {
        AlertDialog.Builder(context).run {
            setTitle("Need Permissions")
            setMessage(
                    (if (isMustBeEnabledPermission) "$permissionName permission must be enabled "
                    else "This app needs $permissionName permission ")
                            + "to $message. You can grant permission in APP SETTINGS -> PERMISSION.")
            setPositiveButton("GOTO APP SETTINGS") { dialog, which ->
                dialog.cancel()
                openSettings(packageName)
                mPermissionRequested = false
            }
            if (!isMustBeEnabledPermission) {
                setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which ->
                    dialog.cancel()
                })
            }
            show()
        }
    }

    private fun openSettings(packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            data = Uri.fromParts("package", packageName, null)
        }
        (mView as Activity).startActivity(intent)
    }

    private fun exitApplication() {
        with(mView as Activity) {
            if (Build.VERSION.SDK_INT in 16..20) {
                finishAffinity()
            } else if (Build.VERSION.SDK_INT >= 21) {
                finishAndRemoveTask()
            }
        }
    }

    private fun getAllMusicList() {
        with(WorkerUtils) {
            val onlineMusicChain = WorkManager.getInstance()
                    .beginWith(buildOneTimeWorkRequest<OnlineMusicWorker>())
                    .then(listOf(
                            buildOneTimeWorkRequest<OnlineAlbumListWorker>(),
                            buildOneTimeWorkRequest<OnlineArtistListWorker>(),
                            buildOneTimeWorkRequest<OnlineGenreListWorker>(),
                            buildOneTimeWorkRequest<OnlinePlaylistListWorker>()))
            val offlineMusicChain = WorkManager.getInstance()
                    .beginWith(buildOneTimeWorkRequest<OfflineMusicWorker>())
                    .then(listOf(
                            buildOneTimeWorkRequest<OfflineAlbumListWorker>(),
                            buildOneTimeWorkRequest<OfflineArtistListWorker>(),
                            buildOneTimeWorkRequest<OfflineGenreListWorker>(),
                            buildOneTimeWorkRequest<OfflinePlaylistListWorker>(),
                            buildOneTimeWorkRequest<OfflineFolderListWorker>(),
                            buildOneTimeWorkRequest<OfflineFavortieListWorker>()))
            WorkContinuation
                    .combine(listOf(onlineMusicChain, offlineMusicChain))
                    .then(mLoadingMusicDoneWorkRequest)
                    .enqueue()
        }
    }
}