package app.music.model

class PlaylistContainer(var playlistList: List<Playlist>?)
