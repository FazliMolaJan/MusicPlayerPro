package app.music.base;

import android.app.Activity;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.os.Handler;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import java.lang.ref.WeakReference;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public abstract class BaseRecyclerAdapter<T, H extends BaseViewHolder>
        extends RecyclerView.Adapter<H>
        implements Filterable {

    protected WeakReference<Activity> mActivityReference;
    private static final String TAG = "BaseRecyclerAdapter";
    protected List<T> mDataList = new ArrayList<>();
    private List<T> mDataListFull = new ArrayList<>();
    private Queue<List<T>> mPendingUpdates = new ArrayDeque<>();

    public BaseRecyclerAdapter(WeakReference<Activity> activityReference) {
        this.mActivityReference = activityReference;
    }

    @Override
    public H onCreateViewHolder(ViewGroup parent, int viewType) {
        ViewDataBinding binding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                getLayoutId(),
                parent,
                false);
        return getViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(H holder, int bindPosition) {
        Log.i(TAG, "on bind view holder");
        Activity activity = mActivityReference.get();
        if (activity == null || mDataList == null || mDataList.size() < bindPosition) return;
        setData(holder, bindPosition);
        setItemClick(holder, activity);
    }

    @Override
    public int getItemCount() {
        return mDataList != null ? mDataList.size() : 0;
    }

    @Override
    public Filter getFilter() {
        return dataFilter;
//        return null;
    }

    private Filter dataFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<T> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList = new ArrayList<>(mDataListFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (T item : mDataListFull) {
                    if (isContainingFilterPatternItem(item, filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }

            FilterResults filterResults = new FilterResults();
            filterResults.values = filteredList;

            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            updateItems(true, (List<T>) results.values);
        }
    };

    public void updateItems(boolean isFilter, final List<T> newItems) {
        mPendingUpdates.add(newItems);
        if (mPendingUpdates.size() > 1) return;
        updateItemsInternal(isFilter, newItems);
    }

    protected abstract H getViewHolder(ViewDataBinding binding);

    protected abstract Object getItemClickListener(Activity activity);

    protected abstract DiffUtil.DiffResult getDiffResult(boolean isFilter, List<T> dataList, List<T> newItems);

    protected abstract int getLayoutId();

    protected abstract boolean isContainingFilterPatternItem(T item, String filterPattern);

    protected void setData(H holder, int position) {
        holder.setDataList(mDataList);
        holder.bindData(mDataList.get(position));
        Log.i(TAG, "setData");
    }

    protected void setItemClick(H holder, Activity activity) {
        holder.setItemClickListener(getItemClickListener(activity));
        Log.i(TAG, "setItemClick");
    }

    private void updateItemsInternal(boolean isFilter, final List<T> newItems) {
        final Handler handler = new Handler();
        new Thread(() -> {
            final DiffUtil.DiffResult diffResult = getDiffResult(isFilter, mDataList, newItems);
            handler.post(() -> applyDiffResult(isFilter, newItems, diffResult));
        }).start();
    }

    private void applyDiffResult(boolean isFilter, List<T> newItems, DiffUtil.DiffResult diffResult) {
        mPendingUpdates.remove();
        dispatchUpdate(isFilter, newItems, diffResult);
        if (mPendingUpdates.size() > 0) {
            updateItemsInternal(isFilter, mPendingUpdates.peek());
        }
    }

    private void dispatchUpdate(boolean isFilter, List<T> newItems, DiffUtil.DiffResult diffResult) {
        if (diffResult != null) {
            diffResult.dispatchUpdatesTo(BaseRecyclerAdapter.this);
        }
        if (!isFilter) {
            mDataListFull.clear();
            mDataListFull.addAll(newItems);
        }
        mDataList.clear();
        mDataList.addAll(newItems);
//        mDataList = new ArrayList<>(newItems);
    }
}
