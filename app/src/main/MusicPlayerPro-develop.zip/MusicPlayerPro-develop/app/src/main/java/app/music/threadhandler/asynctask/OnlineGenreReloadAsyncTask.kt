package app.music.threadhandler.asynctask

import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import app.music.adapter.GenreAdapter
import app.music.base.BaseReloadListAsyncTask
import app.music.model.Genre
import app.music.utils.musicloading.LoadMusicUtil
import java.lang.ref.WeakReference
import java.util.*

class OnlineGenreReloadAsyncTask<C : Comparator<in Genre>>(
        fragmentReference: WeakReference<Fragment>, recyclerAdapter: GenreAdapter,
        refreshLayoutReference: WeakReference<SwipeRefreshLayout>, comparator: C)
    : BaseReloadListAsyncTask<Genre, C, GenreAdapter>(
        fragmentReference, recyclerAdapter, refreshLayoutReference, comparator) {

    override fun reloadTypeList() = LoadMusicUtil.getOnlineGenre()

    override fun getTypeList(): List<Genre> = LoadMusicUtil.sOnlineGenreList
}
