package app.music.threadhandler.asynctask

import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import app.music.adapter.SongAdapter
import app.music.base.BaseReloadListAsyncTask
import app.music.model.BaseMusik
import app.music.model.OnlineMusik
import app.music.utils.musicloading.LoadMusicUtil
import java.lang.ref.WeakReference
import java.util.*

class OnlineSongReloadAsyncTask<C : Comparator<in BaseMusik>>(
        fragmentReference: WeakReference<Fragment>, recyclerAdapter: SongAdapter<*>,
        refreshLayoutReference: WeakReference<SwipeRefreshLayout>, comparator: C)
    : BaseReloadListAsyncTask<OnlineMusik, C, SongAdapter<*>>(
        fragmentReference, recyclerAdapter, refreshLayoutReference, comparator) {

    override fun reloadTypeList() {

    }

    override fun getTypeList(): List<OnlineMusik> = LoadMusicUtil.sOnlineMusicList
}
