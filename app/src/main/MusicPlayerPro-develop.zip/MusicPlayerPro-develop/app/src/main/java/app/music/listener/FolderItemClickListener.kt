package app.music.listener

import app.music.model.Folder

interface FolderItemClickListener {
    fun onFolderClick(folder: Folder, isLongClick: Boolean)
}
