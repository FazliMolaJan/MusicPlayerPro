package app.music.base;

import android.content.Intent;
import android.os.SystemClock;
import android.text.TextUtils;

import com.bumptech.glide.request.RequestOptions;

import org.jetbrains.annotations.NotNull;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import app.music.R;
import app.music.adapter.AlbumSongAdapter;
import app.music.databinding.ActivityDetailAlbumBinding;
import app.music.listener.SongItemClickListener;
import app.music.model.BaseMusik;
import app.music.model.OnlineMusik;
import app.music.utils.ConstantUtil;
import app.music.utils.DoubleClickUtils;
import app.music.utils.gradient.GradientBackgroundUtils;
import app.music.utils.imageloading.ImageLoadingUtils;
import app.music.utils.recyclerview.RecyclerViewUtils;
import app.music.utils.toast.ToastUtil;

public abstract class BaseSingleRecyclerActivity<ObjectType>
        extends BaseBottomProgressActivity<ActivityDetailAlbumBinding>
        implements SongItemClickListener {

    private static final String TAG = "BaseSingleRecyclerActivity";
    private List<BaseMusik> mMusicList = new ArrayList<>();
    //    private OfflineGradientBackgroundAsyncTask mOfflineGradientScrollViewAsyncTask;
//    private OnlineGradientBackgroundAsyncTask mOnlineGradientScrollViewAsyncTask;
    private long mLastClickTime = 0;
    private RequestOptions mRequestOptions = new RequestOptions().error(R.drawable.ic_album);
    private AlbumSongAdapter mRecyclerAdapter;

    @Override
    protected void onPause() {
        super.onPause();
//        ProgressCancelingUtils.INSTANCE.cancelAsyncTask(mOfflineGradientScrollViewAsyncTask);
//        ProgressCancelingUtils.INSTANCE.cancelAsyncTask(mOnlineGradientScrollViewAsyncTask);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mBinding.recyclerView.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_detail_album;
    }

    @Override
    protected int getRootViewId() {
        return R.id.relative_detail_album;
    }

    @Override
    public void initView() {
        setMButtonPlayPause(mBinding.btnPlayPause);
        setMTextPlayingArtist(mBinding.txtPlayingArtist);
        setMTextPlayingSongName(mBinding.txtPlayingSongName);
        setMImagePlayingCover(mBinding.imgPlayingCover);
        setMBottomProgressBar(mBinding.bottomProgressBar);
        setMRelativeBottomBar(mBinding.bottomBar);
        setMButtonNext(mBinding.btnNext);
        setMButtonPrev(mBinding.btnPrev);
        setMBlurBottomBar(mBinding.blurBottom);
        super.initView();

        setSupportActionBar(mBinding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        ObjectType object = null;
        if (intent != null) {
            object = getDataObject(intent);
        }

        String toolbarTitle = getToolbarTitle(object);
        if (!TextUtils.isEmpty(toolbarTitle)) {
            getSupportActionBar().setTitle(toolbarTitle);
        }

        mMusicList = new ArrayList<>(getDataList(object));
        if (mMusicList.size() > 0) {
            BaseMusik music = mMusicList.get(0);
            if (music != null) {
                String musicType = music.getType();
                if (!TextUtils.isEmpty(musicType)) {
                    switch (musicType) {
                        case ConstantUtil.OFFLINE_MUSIC:
                            String songLocation = music.getLocation();
                            if (TextUtils.isEmpty(songLocation)) break;
                            mMetadataRetriever.setDataSource(songLocation);
                            byte[] bytes = mMetadataRetriever.getEmbeddedPicture();
                            if (bytes != null) {
//                                mOfflineGradientScrollViewAsyncTask
//                                        = new OfflineGradientBackgroundAsyncTask(
//                                        new WeakReference<>(this),
//                                        new WeakReference<>(mBinding.coordinatorBackground));
//                                mOfflineGradientScrollViewAsyncTask.execute(bytes);
                                GradientBackgroundUtils.INSTANCE.createGradientBackground(
                                        this, mCompositeDisposable, bytes, mBinding.coordinatorBackground
                                );
                            }
                            ImageLoadingUtils.INSTANCE.loadImage(mBinding.imgCoverArt, bytes, mRequestOptions);
                            break;
                        case ConstantUtil.ONLINE_MUSIC:
                            String coverArtLink = ((OnlineMusik) music).getCoverArt();
                            if (!TextUtils.isEmpty(coverArtLink)) {
//                                mOnlineGradientScrollViewAsyncTask = new OnlineGradientBackgroundAsyncTask(
//                                        new WeakReference<>(this),
//                                        new WeakReference<>(mBinding.coordinatorBackground));
//                                mOnlineGradientScrollViewAsyncTask.execute(coverArtLink);

                                GradientBackgroundUtils.INSTANCE.createGradientBackground(
                                        this, mCompositeDisposable, coverArtLink, mBinding.coordinatorBackground
                                );
                            }
                            ImageLoadingUtils.INSTANCE.loadImage(mBinding.imgCoverArt, coverArtLink, mRequestOptions);
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        RecyclerViewUtils.INSTANCE.setVerticalLinearLayout(
                mBinding.recyclerView, this, true, true);
    }

    @Override
    public void initData() {
        mRecyclerAdapter = new AlbumSongAdapter(new WeakReference<>(this));
        mBinding.recyclerView.setAdapter(mRecyclerAdapter);
        //Collections.sort(mMusicList, new SongComparatorByAlphabetAscending());
        mRecyclerAdapter.updateItems(false, mMusicList);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public <MusicType extends BaseMusik> void onSongClick(
            int position, @NotNull List<? extends MusicType> musicList, boolean isLongClick) {
        if (DoubleClickUtils.INSTANCE.isDoubleClick(mLastClickTime)) return;
        mLastClickTime = SystemClock.elapsedRealtime();
        if (isLongClick) {
            ToastUtil.INSTANCE.showToast("Song Long click" + position);
        } else {
            mMusicService.setList(musicList);
            playPickedSong(musicList.get(position));
        }
    }

    protected abstract ObjectType getDataObject(Intent intent);

    protected abstract String getToolbarTitle(ObjectType object);

    protected abstract List<BaseMusik> getDataList(ObjectType object);
}
