package app.music.viewholder

import android.app.Activity
import android.content.Context
import android.databinding.ObservableField
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.View
import app.music.R
import app.music.base.BaseViewHolder
import app.music.databinding.ItemArtistSecondFragmentBinding
import app.music.listener.SongItemClickListener
import app.music.model.BaseMusik
import app.music.utils.imageloading.ImageLoadingUtils
import com.bumptech.glide.request.RequestOptions
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat

class ArtistSongViewHolder(
        weakReference: WeakReference<Activity>, itemView: ItemArtistSecondFragmentBinding)
    : BaseViewHolder<BaseMusik, ItemArtistSecondFragmentBinding, SongItemClickListener>
(weakReference, itemView) {

    var song = ObservableField<String>()
    var duration = ObservableField<String>()
    private val mSimpleDateFormat = SimpleDateFormat("mm:ss")
    private val mRequestOptions = RequestOptions()
            .centerCrop()
//            .placeholder(R.drawable.default_avatar)
            .error(R.drawable.ic_album)
//            .diskCacheStrategy(DiskCacheStrategy.ALL)
//            .priority(Priority.HIGH)
//            .dontAnimate()
//            .dontTransform();

    override fun bindData(dataObject: BaseMusik) {
        if (mBinding.itemview == null) {
            mBinding.itemview = this
        }
        dataObject.let {
            val context by lazy { mViewHolderWeakReference.get() as Context }
            val defaultValue by lazy { context.getString(R.string.empty_string) }
            setStringObservableFieldValue(context, song, it.title, defaultValue)
            setStringObservableFieldValue(context, duration, mSimpleDateFormat.format(it.duration), defaultValue)
            ImageLoadingUtils.loadMusicImage(it, mMetadataRetriever, mRequestOptions, mBinding.coverArt)
        }
    }

    override fun clickItemListener(position: Int, isLongClick: Boolean) {
        mItemClickListener?.onSongClick(position, mDataList, isLongClick)
    }
}
