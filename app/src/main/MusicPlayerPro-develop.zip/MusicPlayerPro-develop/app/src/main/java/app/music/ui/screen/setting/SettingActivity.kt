package app.music.ui.screen.setting

import android.view.Menu
import app.music.R
import app.music.base.BaseMVVMActivity
import app.music.base.contract.SettingActivityContract
import app.music.databinding.ActivitySettingBinding
import app.music.utils.blur.DynamicBlurUtils
import app.music.utils.intent.IntentMethodUtils
import app.music.utils.theme.ThemeConstantUtils
import app.music.utils.theme.ThemeMethodUtils
import app.music.viewmodel.SettingActivityViewModel
import kotlinx.android.synthetic.main.activity_setting.*
import java.lang.ref.WeakReference

class SettingActivity : BaseMVVMActivity<ActivitySettingBinding, SettingActivityViewModel>(),
        SettingActivityContract.View {

    override fun getViewModel(): SettingActivityViewModel = SettingActivityViewModel()

    override fun initInject() = activityComponent.inject(this)

    override fun getLayoutId(): Int = R.layout.activity_setting

    override fun getLogTag(): String = TAG

    override fun getOptionMenuId(): Int = 0

    override fun createOptionMenu(menu: Menu) {

    }

    override fun initView() {
        DynamicBlurUtils.blurView(this, R.id.coordinator_background, mBinding.blurToolBar)
        binding.settingActivityViewModel = mViewModel
        mViewModel.checkDarkMode()
        setViewClickListener()
    }

    override fun initData() {

    }

    private fun setViewClickListener() {
        text_theme.setOnClickListener { IntentMethodUtils.launchChooseThemeActivity(this) }
        check_dark_mode.setOnClickListener {
            mViewModel.mIsDarkModeEnabled.set(!mViewModel.mIsDarkModeEnabled.get())
            ThemeMethodUtils.saveCurrentThemeMode(
                    WeakReference(this),
                    if (mViewModel.mIsDarkModeEnabled.get()) ThemeConstantUtils.PREF_DARK_MODE
                    else ThemeConstantUtils.PREF_LIGHT_MODE)
            recreate()
        }
    }

    companion object {

        private const val TAG = "SettingActivity"
    }
}
