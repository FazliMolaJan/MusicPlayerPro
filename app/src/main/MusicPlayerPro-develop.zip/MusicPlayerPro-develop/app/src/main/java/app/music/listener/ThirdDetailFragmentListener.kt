package app.music.listener

interface ThirdDetailFragmentListener {
    fun updateLyrics(lyrics: String)
}
