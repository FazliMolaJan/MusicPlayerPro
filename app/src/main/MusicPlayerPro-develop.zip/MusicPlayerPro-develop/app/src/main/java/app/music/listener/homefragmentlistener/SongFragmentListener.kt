package app.music.listener.homefragmentlistener

import app.music.listener.RecyclerScrollToTopListener

interface SongFragmentListener : RecyclerScrollToTopListener {

    fun onSongListReload(reloadList: Boolean, sortBy: String, isAscending: String)

//    fun onFilterList(filterPattern: String)
}
