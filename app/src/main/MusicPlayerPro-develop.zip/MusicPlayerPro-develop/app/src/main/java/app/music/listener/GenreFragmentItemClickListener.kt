package app.music.listener

import android.app.Activity
import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import android.os.SystemClock
import android.support.v4.app.FragmentActivity
import app.music.model.Genre
import app.music.utils.DoubleClickUtils
import app.music.utils.intent.IntentMethodUtils
import app.music.utils.toast.ToastUtil
import app.music.utils.viewmodel.ViewModelUtils
import app.music.viewmodel.BaseHomeActivityViewModel

interface GenreFragmentItemClickListener {

    fun onGenreClick(genre: Genre, isLongClick: Boolean) {
        val mHomeActivityViewModel = ViewModelUtils.getViewModel<BaseHomeActivityViewModel>(this as Activity)
        with(mHomeActivityViewModel) {
            if (!DoubleClickUtils.isDoubleClick(getItemLastClickTime())) {
                setItemLastClickTime(SystemClock.elapsedRealtime())
                if (isLongClick) {
                    ToastUtil.showToast("Album Long click${genre.genre}")
                } else {
                    IntentMethodUtils.launchDetailGenreActivity(
                            this@GenreFragmentItemClickListener as Context, genre)
                }
            } else {
                setItemLastClickTime(SystemClock.elapsedRealtime())
            }
        }
    }
}
