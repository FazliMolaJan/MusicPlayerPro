package app.music.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.Transformations;

import app.music.utils.TestLambda;

public class Trans {
//    LiveData<TestLambda.User> userLiveData = ...;
//    LiveData<String> userName = Transformations.map(userLiveData, user -> {
//        user.name + " " + user.lastName
//    });
}
