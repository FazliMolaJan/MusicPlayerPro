package app.music.utils.log

import android.util.Log

object InformationLogUtils {

    private const val TAG = "InformationLogUtils"

    //Lifecycle Log
    fun logOnAttach(tag: String) {
        Log.i("$TAG: $tag", "OnAttach")
    }

    fun logOnCreate(tag: String) {
        Log.i("$TAG: $tag", "OnCreate")
    }

    fun logOnCreateView(tag: String) {
        Log.i("$TAG: $tag", "OnCreateView")
    }

    fun logOnActivityCreated(tag: String) {
        Log.i("$TAG: $tag", "OnActivityCreated")
    }

    fun logOnStart(tag: String) {
        Log.i("$TAG: $tag", "OnStart")
    }

    fun logOnResume(tag: String) {
        Log.i("$TAG: $tag", "OnResume")
    }

    fun logOnPause(tag: String) {
        Log.i("$TAG: $tag", "OnPause")
    }

    fun logOnStop(tag: String) {
        Log.i("$TAG: $tag", "OnStop")
    }

    fun logOnDestroyView(tag: String) {
        Log.i("$TAG: $tag", "OnDestroyView")
    }

    fun logOnDestroy(tag: String) {
        Log.i("$TAG: $tag", "OnDestroy")
    }

    fun logOnDetach(tag: String) {
        Log.i("$TAG: $tag", "OnDetach")
    }

    fun logOnRestart(tag: String) {
        Log.i("$TAG: $tag", "OnRestart")
    }

    //Service Log
    fun logOnBind(tag: String) {
        Log.i("$TAG: $tag", "OnBind")
    }

    fun logOnUnbind(tag: String) {
        Log.i("$TAG: $tag", "OnUnbind")
    }

    fun logOnRebind(tag: String) {
        Log.i("$TAG: $tag", "OnRebind")
    }

    fun logServiceConnected(tag: String) {
        Log.i("$TAG: $tag", "Service Bound")
    }

    fun logServiceDisconnected(tag: String) {
        Log.i("$TAG: $tag", "Service Unbound")
    }

    fun logServiceIsNotStarted(tag: String) {
        Log.i("$TAG: $tag", "Service Is Not Started")
    }

    fun logServiceIsNotRunning(tag: String) {
        Log.i("$TAG: $tag", "Service Is Not Running")
    }

    //Notification Log
    fun logNotificationIsPositiveState(tag: String) {
        Log.i("$TAG: $tag", "Notification State =1")
    }

    fun logNotificationIsNegativeState(tag: String) {
        Log.i("$TAG: $tag", "Notification State = -1")
    }

    //Other Log
    fun logRunnableIsRunning(tag: String) {
        Log.i("$TAG: $tag", "Runnable Is Running")
    }

    fun logCoverArtWasSent(tag: String) {
        Log.i("$TAG: $tag", "Cover Art Was Sent")
    }

    fun logSetDefaultBackground(tag: String) {
        Log.i("$TAG: $tag", "Set Default Background")
    }

    fun logGetAllListMusicDone(tag: String) {
        Log.i("$TAG: $tag", "Get All List Music Done")
    }

    fun logMusicThreadStart(tag: String) {
        Log.i("$TAG: $tag", "Music Thread Start")
    }

    fun logOnlineMusicThreadStart(tag: String) {
        Log.i("$TAG: $tag", "Online Music Thread Start")
    }

    fun logSongThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logSongThreadStart")
    }

    fun logAlbumThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logAlbumThreadStart")
    }

    fun logOnlineSongThreadStart(tag: String) {
        Log.i("$TAG: $tag", "Song Thread Start")
    }

    fun logArtistThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logArtistThreadStart")
    }

    fun logOnlineArtistThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logOnlineArtistThreadStart")
    }

    fun logOnlineAlbumThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logOnlineAlbumThreadStart")
    }

    fun logGenreThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logGenreThreadStart")
    }

    fun logFolderThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logFolderThreadStart")
    }

    fun logOnlineGenreThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logOnlineGenreThreadStart")
    }

    fun logPlaylistThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logPlaylistThreadStart")
    }

    fun logOnlinePlaylistThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logOnlinePlaylistThreadStart")
    }

    fun logFavoriteThreadStart(tag: String) {
        Log.i("$TAG: $tag", "logFavoriteThreadStart")
    }
}
