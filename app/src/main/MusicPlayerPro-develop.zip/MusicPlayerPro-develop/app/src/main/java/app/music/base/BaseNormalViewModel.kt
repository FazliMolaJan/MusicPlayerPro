package app.music.base

import android.arch.lifecycle.ViewModel

open class BaseNormalViewModel<T : BaseView> : ViewModel(), BaseViewModel {

    protected var mView: T? = null

    override fun attachView(view: BaseView) {
        this.mView = view as T
    }

    override fun detachView() {
        this.mView = null
    }
}
