package app.music.base.contract

import android.app.Activity
import android.os.Handler
import app.music.base.BaseView
import app.music.base.BaseViewModel

interface SplashActivityContract {

    interface View : BaseView {

        var mHandler: Handler
        var isOnPausing: Boolean
    }

    interface ViewModel : BaseViewModel {

        fun requestStoragePermission(activity: Activity, packageName: String)

        fun loadMusic()
    }
}