package app.music.listener

interface DetailPlayMusicListener {
    fun changePlayButtonImageResource(resId: Int)

    fun changeExoPlayerState()
}
