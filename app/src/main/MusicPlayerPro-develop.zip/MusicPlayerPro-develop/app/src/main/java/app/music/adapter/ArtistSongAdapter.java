package app.music.adapter;

import android.app.Activity;
import android.databinding.ViewDataBinding;
import android.support.v7.util.DiffUtil;

import org.jetbrains.annotations.NotNull;

import java.lang.ref.WeakReference;
import java.util.List;

import app.music.R;
import app.music.base.BaseRecyclerAdapter;
import app.music.databinding.ItemArtistSecondFragmentBinding;
import app.music.diffcallback.SongDiffCallBack;
import app.music.listener.SongItemClickListener;
import app.music.model.BaseMusik;
import app.music.viewholder.ArtistSongViewHolder;

public class ArtistSongAdapter<MusicType extends BaseMusik>
        extends BaseRecyclerAdapter<MusicType, ArtistSongViewHolder> {

    public ArtistSongAdapter(WeakReference<Activity> mActivityWeakReference) {
        super(mActivityWeakReference);
    }

    @Override
    protected ArtistSongViewHolder getViewHolder(ViewDataBinding binding) {
        return new ArtistSongViewHolder(
                mActivityReference, (ItemArtistSecondFragmentBinding) binding);
    }

    @Override
    protected Object getItemClickListener(Activity activity) {
        return new SongItemClickListener() {
            @Override
            public <MusicType extends BaseMusik> void onSongClick(int position, @NotNull List<? extends MusicType> musicList, boolean isLongClick) {
                ((SongItemClickListener) activity).onSongClick(position, musicList, isLongClick);
            }
        };
    }

    @Override
    protected DiffUtil.DiffResult getDiffResult(
            boolean isFilter, List<MusicType> dataList, List<MusicType> newItems) {
        return DiffUtil.calculateDiff(new SongDiffCallBack(dataList, newItems), false);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.item_artist_second_fragment;
    }

    @Override
    protected boolean isContainingFilterPatternItem(BaseMusik item, String filterPattern) {
        return item.getTitle().toLowerCase().contains(filterPattern);
    }
}
