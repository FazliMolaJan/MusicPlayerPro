package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemArtistFirstFragmentBinding
import app.music.diffcallback.AlbumDiffCallBack
import app.music.listener.AlbumFragmentItemClickListener
import app.music.model.Album
import app.music.viewholder.ArtistAlbumViewHolder
import java.lang.ref.WeakReference

class ArtistAlbumAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<Album, ArtistAlbumViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): ArtistAlbumViewHolder {
        return ArtistAlbumViewHolder(
                mActivityReference, binding as ItemArtistFirstFragmentBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
        return object : AlbumFragmentItemClickListener {
            override fun onAlbumClick(album: Album, isLongClick: Boolean) {
                (activity as AlbumFragmentItemClickListener).onAlbumClick(album, isLongClick)
            }
        }
    }

    override fun getDiffResult(
            isFilter: Boolean, dataList: List<Album>, newItems: List<Album>): DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(AlbumDiffCallBack(dataList, newItems), false)
    }

    override fun getLayoutId(): Int = R.layout.item_artist_first_fragment

    override fun isContainingFilterPatternItem(item: Album, filterPattern: String): Boolean {
        return item.albumName.toLowerCase().contains(filterPattern)
    }
}
