package app.music.threadhandler.asynctask

import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import app.music.adapter.SongAdapter
import app.music.base.BaseReloadListAsyncTask
import app.music.model.Music
import app.music.utils.musicloading.LoadMusicUtil
import java.lang.ref.WeakReference
import java.util.*

class SongReloadAsyncTask<C : Comparator<in Music>>(
        fragmentReference: WeakReference<Fragment>, recyclerAdapter: SongAdapter<*>,
        refreshLayoutReference: WeakReference<SwipeRefreshLayout>, comparator: C)
    : BaseReloadListAsyncTask<Music, C, SongAdapter<*>>(
        fragmentReference, recyclerAdapter, refreshLayoutReference, comparator) {

    override fun reloadTypeList() {

    }

    override fun getTypeList(): List<Music> = LoadMusicUtil.sMusicList
}
