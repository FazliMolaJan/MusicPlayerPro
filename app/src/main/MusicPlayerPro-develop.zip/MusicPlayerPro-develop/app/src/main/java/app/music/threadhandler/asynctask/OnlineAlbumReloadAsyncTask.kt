package app.music.threadhandler.asynctask

import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import app.music.adapter.AlbumAdapter
import app.music.base.BaseReloadListAsyncTask
import app.music.model.Album
import app.music.utils.musicloading.LoadMusicUtil
import java.lang.ref.WeakReference
import java.util.*

class OnlineAlbumReloadAsyncTask<C : Comparator<in Album>>(
        fragmentReference: WeakReference<Fragment>, recyclerAdapter: AlbumAdapter,
        refreshLayoutReference: WeakReference<SwipeRefreshLayout>, comparator: C)
    : BaseReloadListAsyncTask<Album, C, AlbumAdapter>(
        fragmentReference, recyclerAdapter, refreshLayoutReference, comparator) {

    override fun reloadTypeList() = LoadMusicUtil.getOnlineAlbum()

    override fun getTypeList(): List<Album> = LoadMusicUtil.sOnlineAlbumList
}
