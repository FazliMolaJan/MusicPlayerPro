package app.music.viewholder

import android.app.Activity
import android.content.Context
import android.databinding.ObservableField
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.View
import app.music.R
import app.music.base.BaseViewHolder
import app.music.databinding.ItemHomeSixthFragmentBinding
import app.music.listener.FolderItemClickListener
import app.music.model.Folder
import java.lang.ref.WeakReference

class FolderViewHolder(
        weakReference: WeakReference<Activity>, itemView: ItemHomeSixthFragmentBinding)
    : BaseViewHolder<Folder, ItemHomeSixthFragmentBinding, FolderItemClickListener>
(weakReference, itemView) {

    var folder = ObservableField<String>()

    override fun bindData(dataObject: Folder) {
        if (mBinding.itemview == null) {
            mBinding.itemview = this
        }
        dataObject.let {
            val context by lazy { mViewHolderWeakReference.get() as Context }
            val defaultValue by lazy { context.getString(R.string.empty_string) }
            setStringObservableFieldValue(context, folder, it.folderName, defaultValue)
        }
    }

    override fun clickItemListener(position: Int, isLongClick: Boolean) {
        mItemClickListener?.onFolderClick(mDataList[position], isLongClick)
    }
}
