package app.music.adapter

import android.app.Activity
import android.databinding.ViewDataBinding
import android.support.v7.util.DiffUtil
import android.support.v7.widget.RecyclerView
import app.music.R
import app.music.base.BaseRecyclerAdapter
import app.music.databinding.ItemHomeFirstFragmentBinding
import app.music.diffcallback.AlbumDiffCallBack
import app.music.diffcallback.FilterAlbumDiffCallBack
import app.music.listener.AlbumFragmentItemClickListener
import app.music.model.Album
import app.music.utils.recyclerview.RecyclerViewUtils
import app.music.viewholder.AlbumViewHolder
import java.lang.ref.WeakReference


class AlbumAdapter(mActivityWeakReference: WeakReference<Activity>)
    : BaseRecyclerAdapter<Album, AlbumViewHolder>(mActivityWeakReference) {

    override fun getViewHolder(binding: ViewDataBinding): AlbumViewHolder {
        return AlbumViewHolder(mActivityReference, binding as ItemHomeFirstFragmentBinding)
    }

    override fun getItemClickListener(activity: Activity): Any {
        return object : AlbumFragmentItemClickListener {
            override fun onAlbumClick(album: Album, isLongClick: Boolean) {
                (activity as AlbumFragmentItemClickListener).onAlbumClick(album, isLongClick)
            }
        }
    }

    override fun getDiffResult(
            isFilter: Boolean, dataList: List<Album>, newItems: List<Album>): DiffUtil.DiffResult {
        return DiffUtil.calculateDiff(
                if (isFilter) FilterAlbumDiffCallBack(dataList, newItems)
                else AlbumDiffCallBack(dataList, newItems),
                false)
    }

    override fun getLayoutId(): Int = R.layout.item_home_first_fragment

    override fun isContainingFilterPatternItem(item: Album, filterPattern: String): Boolean {
        return item.albumName.toLowerCase().contains(filterPattern)
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        RecyclerViewUtils.setToolbarScrollFlag(recyclerView, mActivityReference)
    }
}
