package app.music.ui.screen.artist;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;

import java.lang.ref.WeakReference;
import java.util.Comparator;

import app.music.R;
import app.music.adapter.ArtistAdapter;
import app.music.threadhandler.asynctask.OnlineArtistReloadAsyncTask;
import app.music.base.BaseFragment;
import app.music.comparator.comparatorascending.artist.ArtistComparatorByAlphabetAscending;
import app.music.comparator.comparatorascending.artist.ArtistComparatorByNumberOfAlbumsAscending;
import app.music.comparator.comparatorascending.artist.ArtistComparatorByNumberOfSongsAscending;
import app.music.comparator.comparatordescending.artist.ArtistComparatorByAlphabetDescending;
import app.music.comparator.comparatordescending.artist.ArtistComparatorByNumberOfAlbumsDescending;
import app.music.comparator.comparatordescending.artist.ArtistComparatorByNumberOfSongsDescending;
import app.music.databinding.FragmentArtistBinding;
import app.music.listener.homefragmentlistener.ArtistFragmentListener;
import app.music.ui.screen.onlinemusic.OnlineHomeActivity;
import app.music.utils.musicloading.HomeFragmentDataUpdatingUtil;
import app.music.utils.musicloading.LoadMusicUtil;
import app.music.utils.progresscanceling.ProgressCancelingUtils;
import app.music.utils.recyclerview.RecyclerViewUtils;
import app.music.utils.sort.SortConstantUtils;
import app.music.utils.sort.SortMethodUtils;

public class OnlineArtistFragment extends BaseFragment<FragmentArtistBinding>
        implements SwipeRefreshLayout.OnRefreshListener, ArtistFragmentListener {

    private static final String TAG = "ArtistFragment";
    private ArtistAdapter mArtistRecyclerAdapter;
    private OnlineArtistReloadAsyncTask<? extends Comparator> mArtistReloadAsyncTask;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        ((OnlineHomeActivity) context).setMArtistFragmentListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        ProgressCancelingUtils.INSTANCE.cancelAsyncTask(mArtistReloadAsyncTask);
        getBinding().refreshlayout.setRefreshing(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getBinding().recyclerview.setAdapter(null);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_artist;
    }

    @Override
    public String getLogTag() {
        return TAG;
    }

    @Override
    public void initView() {
        RecyclerViewUtils.INSTANCE.setVerticalLinearLayout(
                getBinding().recyclerview, getContext(), true, true);
        getBinding().refreshlayout.setOnRefreshListener(this);
    }

    @Override
    public void initData() {
        mArtistRecyclerAdapter = new ArtistAdapter(new WeakReference<>(getActivity()));
        getBinding().recyclerview.setAdapter(mArtistRecyclerAdapter);
        reloadData(false);
        mArtistRecyclerAdapter.updateItems(false, LoadMusicUtil.sOnlineArtistList);
    }

    @Override
    public void onRefresh() {
        reloadData(true);
    }

    @Override
    public void onArtistListReload(boolean reloadList, String sortBy, String isAscending) {
        switch (sortBy) {
            case SortConstantUtils.PREF_ARTIST_SORT_BY_ALPHABET:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new ArtistComparatorByAlphabetAscending() :
                                new ArtistComparatorByAlphabetDescending());
                break;
            case SortConstantUtils.PREF_ARTIST_SORT_BY_NUMBER_OF_ALBUMS:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new ArtistComparatorByNumberOfAlbumsAscending() :
                                new ArtistComparatorByNumberOfAlbumsDescending());
                break;
            case SortConstantUtils.PREF_ARTIST_SORT_BY_NUMBER_OF_SONGS:
                reloadList(reloadList,
                        isAscending.equals(SortConstantUtils.PREF_ORDER_BY_ASCENDING) ?
                                new ArtistComparatorByNumberOfSongsAscending() :
                                new ArtistComparatorByNumberOfSongsDescending());
                break;
        }
    }

    @Override
    public void onScrollToTop() {
        getBinding().recyclerview.scrollToPosition(0);
    }

    public void reloadData(boolean reloadList) {
        String[] sortState = SortMethodUtils.INSTANCE.getArtistSortState(new WeakReference<>(getActivity()));
        onArtistListReload(reloadList, sortState[0], sortState[1]);
    }

    private <C extends Comparator> void reloadList(Boolean reloadMusicList, C comparator) {
        HomeFragmentDataUpdatingUtil.INSTANCE.updateOnlineArtistList(getActivity(),
                getCompositeDisposable(), mArtistRecyclerAdapter, getBinding().refreshlayout,
                comparator, ((OnlineHomeActivity) getActivity()).mRetrofit, reloadMusicList);
    }
}
